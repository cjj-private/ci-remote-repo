import json
import logging
from datetime import datetime, timedelta

import requests
from apscheduler.schedulers.blocking import BlockingScheduler
from kubernetes import client, config

logging.basicConfig(level=logging.INFO)
sched = BlockingScheduler()
k8s = {
    '生产现货k8s环境': {'config': '/root/.kube/new-cluster-config', 'namespaces': ['default']},
    '生产永续k8s环境': {'config': '/root/.kube/config', 'namespaces': ['default', 'hotcoin']},
    '生产交割k8s环境': {'config': '/root/.kube/deliver', 'namespaces': ['default']},
}

def alarm(env, namespace, pod, reason, message):
    # Teams 通道 URL
    url = 'https://prod-30.australiasoutheast.logic.azure.com:443/workflows/f76d6cd800444879a5e117689e66f32c/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=vRHDtochEduopoPfmOYeo_NWxEwjUVkXJ3VZBGXTUcM'
    contract_url = 'https://slipshield20.webhook.office.com/webhookb2/b3b092a5-c469-4075-9498-efbd4cdd5a11@58d4b05c-9dd8-4581-afa2-8aea221aba21/IncomingWebhook/0d50d459e2354c3a8591b3abf3f1555b/a134271e-c2f2-4108-8aa2-ddf306eca287/V2ivzcNCYfrQITTkrngt3ZIDSp8LnBf_woLl2alsA9rBs1'
    new_coin_url = 'https://slipshield20.webhook.office.com/webhookb2/8298452e-097a-47d6-a6c3-f69b5cf26ab2@58d4b05c-9dd8-4581-afa2-8aea221aba21/IncomingWebhook/d1ff0b7bbda749cabafb90d2470cf8a4/a134271e-c2f2-4108-8aa2-ddf306eca287/V2PIJ6zpIdoTuLIrj-g0rvLW8880OZNe-_4bmNQPiX-sQ1'

    # Lark 通道 URL
    lark_contract_url = 'https://open.larksuite.com/open-apis/bot/v2/hook/856c6ecb-b1bd-469d-ac61-60fce78745a1'
    lark_new_coin_url = 'https://open.larksuite.com/open-apis/bot/v2/hook/5f5f5db1-10a6-4a27-8cf7-024355ac89ae'

    # Teams 消息格式
    teams_message = (
        f"# {env}pod不健康 \r- namespace: {namespace} \r- pod: {pod} \r- 原因: {reason}, {message}"
    )
    payload = {'type': 'message', 'attachments': [{'contentType': 'application/vnd.microsoft.card.adaptive', 'contentUrl': None, 'content': {'type': 'AdaptiveCard', 'version': '1.2', 'body': [{'wrap': True, 'type': 'TextBlock', 'text': teams_message}]}}]}

    # Lark 消息格式
    lark_message = (
        f"{env}pod不健康\n"
        f"namespace: {namespace}\n"
        f"pod: {pod}\n"
        f"原因: {reason}, {message}"
    )
    lark_payload = {"msg_type": "text", "content": {"text": lark_message}}

    # 发送到通用 Teams 通道
    requests.post(url, json=payload)

    # 如果消息中包含 "永续" 或 "交割"，发送到相应的 Teams 和 Lark 通道
    if '永续' in env or '交割' in env:
        requests.post(contract_url, json=payload)
        requests.post(lark_contract_url, json=lark_payload)

    # 如果消息中包含 "现货"，发送到相应的 Teams 和 Lark 通道
    if '现货' in env:
        requests.post(new_coin_url, json=payload)
        requests.post(lark_new_coin_url, json=lark_payload)

@sched.scheduled_job('interval', seconds=60)
def tick():
    for env, value in k8s.items():
        config.load_kube_config(value['config'])
        v1 = client.CoreV1Api()

        for namespace in value['namespaces']:
            for event in v1.list_namespaced_event(namespace).items:
                # 过滤过时事件
                event_time = event.last_timestamp if event.last_timestamp else event.event_time

                # 检查事件类型
                if event.reason in ['Unhealthy', 'BackOff'] and any(e in event.message for e in ['Readiness probe failed', 'Liveness probe failed', 'Back-off']):
                    pod_id = event.involved_object.name

                    # 检查 Pod 是否存在并过滤 Terminating 状态
                    try:
                        pod_info = v1.read_namespaced_pod(name=pod_id, namespace=namespace)
                        if pod_info.status.phase == "Terminating":
                            logging.info(f"Skipping pod {pod_id} in namespace {namespace} because it's in Terminating state.")
                            continue
                        if pod_info.status.phase == "Running" and all(c.ready for c in pod_info.status.container_statuses):
                            logging.info(f"Pod {pod_id} is healthy, skipping alarm.")
                            continue
                    except client.exceptions.ApiException as e:
                        if e.status == 404:
                            logging.info(f"Pod {pod_id} in namespace {namespace} no longer exists, skipping.")
                            continue
                        else:
                            logging.error(f"Error checking Pod {pod_id}: {e}")
                            continue

                    # 调用 alarm 函数，传递动态参数
                    alarm(
                        env=env,
                        namespace=namespace,
                        pod=pod_id,
                        reason=event.reason,
                        message=event.message
                    )

sched.start()

