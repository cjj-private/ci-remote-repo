
import datetime
import os
import time

import oss2
import qrcode
import requests

# 获取环境变量
job_name=os.environ.get('JOB_NAME', '').strip()
flavors_type = os.environ.get('FLAVORS_TYPE', '').strip()
print(f"DEBUG: flavors_type = '{flavors_type}'")
build_type = os.environ.get('BUILD_TYPE', '').strip()
print(f"DEBUG: flavors_type = '{flavors_type}', build_type = '{build_type}'")
#path = f"/root/.jenkins/workspace/andriod/app/build/outputs/apk/{flavors_type}/{build_type}"
path = f'/root/.jenkins/workspace/{job_name}/app/build/outputs/apk/{flavors_type}/{build_type.lower()}'
print(f"DEBUG: path = {path}")
#path = f'/apps/jenkins-test/data/workspace/android/app/build/outputs/apk/{flavors_type}/{build_type.lower()}'
#path = f'/apps/jenkins-test/data/workspace/android/app/build/outputs/apk/Develop/{build_type.lower()}'
img_url= 'https://test-newadminbkt.oss-cn-hongkong.aliyuncs.com/hotcoin/android_apk.jpg'
build_time = time.strftime('%Y-%m-%d-%H-%M-%S', time.localtime(time.time()))

def upload_mapping_file(bucket):
    """上传 mapping.txt 文件到 OSS"""
    mapping_file_path = '/root/.jenkins/workspace/{job_name}/app/mapping.txt'
    if os.path.exists(mapping_file_path):
        oss_filename = f'{build_time}-mapping.txt'
        mapping_download_url = f'https://test-newadminbkt.oss-cn-hongkong.aliyuncs.com/hotcoin/{oss_filename}'
        result = bucket.put_object_from_file(f'hotcoin/{oss_filename}', mapping_file_path)
        if result.status == 200:
            print("mapping.txt 文件上传成功：", mapping_download_url)
        else:
            print("mapping.txt 文件上传失败。")
    else:
        print("mapping.txt 文件不存在，跳过上传。")


def upload_oss():
    auth = oss2.Auth('LTAI5tAd9TVi5Hu8LoB6oyNy', 'YsnU3ceRUjs2Edh9a7BXVA2eCRNKQU')
    bucket = oss2.Bucket(auth, 'http://oss-cn-hongkong-internal.aliyuncs.com', 'test-newadminbkt')

    dirs = os.listdir(path)
    for filename in dirs:
        if ".apk" in filename:
            #print(filename,type(filename))
            #删除旧图片
            #delete_img()
            oss_filename=build_time+"-"+filename
            download_url = 'https://test-newadminbkt.oss-cn-hongkong.aliyuncs.com/hotcoin/'+oss_filename
            result=bucket.put_object_from_file('hotcoin/%s'%(oss_filename), '%s/%s'%(path,filename))
            if result.status == 200:
               #二维码
               img = qrcode.make(data=download_url)
               img.save("/data/scripts/apk.jpg")
               img_filename=build_time+"-"+filename
               bucket.put_object_from_file('hotcoin/%s.jpg'%(img_filename),'/data/scripts/apk.jpg')
 #              with open('/data/scripts/jpg.txt','w') as f1:
 #                   f1.write(filename)

               #with open('/root/.jenkins/workspace/android/changelog','r') as f2:
               #     commit_info=f2.read()

               send_markdown_msg(download_url, img_filename)
            else:
                print("apk上传不成���")


    # 如果是 Release 类型，上传 mapping.txt 文件
    if build_type.lower() == 'release':
        upload_mapping_file(bucket)



def send_markdown_msg(download_url, img_name):
    branch = os.environ.get('BRANCH', '')
    job_url = os.environ.get('JOB_URL', '')
    build_id = os.environ.get('BUILD_ID', '')
    change_log = os.environ.get('CHANGELOG', '')
    markdown = '## 测试版apk打包成功\n'
    markdown += f'### 任务: {job_name}\n'
    markdown += f'### 分支: {branch}\n'
    markdown += f'### 编号: [#{build_id}]({job_url})\n'
    markdown += f'### 构建类型: {build_type}\n'
    markdown += f'### 安装包: [点击或扫码下载↓]({download_url})\n'
    markdown += f'### 提交记录:\n{change_log}\n'
    markdown += f'![screenshot](https://test-newadminbkt.oss-cn-hongkong.aliyuncs.com/hotcoin/{img_name}.jpg)\n'

    #teams_url = 'https://slipshield20.webhook.office.com/webhookb2/775f32e1-1f35-4a33-84e8-57090292c654@58d4b05c-9dd8-4581-afa2-8aea221aba21/IncomingWebhook/e13e882a14b6482d916030ef2004daf0/90a83017-a9b4-4907-ad5d-f3f1f6d01351'
    teams_url = 'https://slipshield20.webhook.office.com/webhookb2/775f32e1-1f35-4a33-84e8-57090292c654@58d4b05c-9dd8-4581-afa2-8aea221aba21/IncomingWebhook/bd7f9b0dc3a144d5bd2d1afcfe19da45/a134271e-c2f2-4108-8aa2-ddf306eca287/V2iilk15ukPyYFH6_JBno5fZF9AP-2EkEJFjLiNQeLXnE1'
    payload = {'text': markdown}
    requests.post(teams_url, json=payload)


upload_oss()
