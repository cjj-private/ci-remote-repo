import os
import time
import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder
import oss2
import qrcode
import json

# 配置参数
APP_ID = "cli_a7fc879c6ab9902f"
APP_SECRET = "upCGRHdOrHrIzp7EBsWuMgFaSYxT8EeN"
CHAT_ID = "oc_9381007863c6024c44b4b3510e91460e"
#CHAT_ID = "oc_d277d599b95e4d915dfadab7937199ff"
BUCKET_NAME = "test-newadminbkt"
OSS_ENDPOINT = "http://oss-cn-hongkong-internal.aliyuncs.com"

# 获取环境变量
job_name = os.environ.get('JOB_NAME', 'unknown').strip()
flavors_type = os.environ.get('FLAVORS_TYPE', 'unknown').strip()
build_type = os.environ.get('BUILD_TYPE', 'debug').strip().lower()
branch = os.environ.get('BRANCH', 'unknown').strip()
build_id = os.environ.get('BUILD_ID', 'unknown').strip()
job_url = os.environ.get('JOB_URL', '').strip()
change_log = os.environ.get('CHANGELOG', '').strip()

print(f"Job Name: {job_name} (length: {len(job_name)})")
print(f"Branch: {branch} (length: {len(branch)})")
print(f"Build ID: {build_id} (length: {len(build_id)})")
print(f"Build Type: {build_type} (length: {len(build_type)})")
print(f"Job URL: {job_url} (length: {len(job_url)})")
print(f"Change Log: {change_log} (length: {len(change_log)})")

path = f'/root/.jenkins/workspace/{job_name}/app/build/outputs/apk/{flavors_type}/{build_type}'
build_time = time.strftime('%Y-%m-%d-%H-%M-%S', time.localtime(time.time()))

def get_tenant_access_token(app_id, app_secret):
    """获取飞书的 tenant_access_token"""
    url = "https://open.larksuite.com/open-apis/auth/v3/tenant_access_token/internal"
    payload = {"app_id": app_id, "app_secret": app_secret}
    response = requests.post(url, json=payload)
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 0:
            return result.get("tenant_access_token")
        else:
            raise Exception(f"Failed to get token: {result.get('msg')}")
    else:
        raise Exception(f"HTTP error: {response.status_code}")

def upload_image_from_url_to_lark(oss_url, access_token):
    """从 OSS 下载图片并上传到飞书"""
    response = requests.get(oss_url, stream=True)
    if response.status_code == 200:
        url = "https://open.larksuite.com/open-apis/im/v1/images"
        headers = {'Authorization': f'Bearer {access_token}'}
        form = MultipartEncoder(
            fields={
                'image_type': 'message',
                'image': ('oss_image.jpg', response.content, 'image/jpeg')
            }
        )
        headers['Content-Type'] = form.content_type
        upload_response = requests.post(url, headers=headers, data=form)
        if upload_response.status_code == 200:
            result = upload_response.json()
            if result.get("code") == 0:
                return result['data']['image_key']
            else:
                raise Exception(f"Failed to upload image: {result.get('msg')}")
        else:
            raise Exception(f"HTTP error during upload: {upload_response.status_code}")
    else:
        raise Exception(f"Failed to download image from OSS: {response.status_code}")

def send_interactive_message_with_info(chat_id, access_token, image_key, job_name, branch, build_id, build_type, job_url, download_url, change_log):
    """发送包含信息和图片的交互消息到飞书"""
    url = "https://open.larksuite.com/open-apis/im/v1/messages?receive_id_type=chat_id"
    headers = {'Authorization': f'Bearer {access_token}', 'Content-Type': 'application/json'}

    card_content = {
        "config": {"wide_screen_mode": True},
        "header": {
            "template": "blue",
            "title": {"tag": "plain_text", "content": "测试版APK打包成功"}
        },
        "elements": [
            {
                "tag": "div",
                "text": {
                    "tag": "lark_md",
                    "content": f"**任务**: {job_name}\n**分支**: {branch}\n**编号**: #{build_id} [查看详情]({job_url})\n**构建类型**: {build_type}\n**安装��**: [点击或扫码下载]({download_url})\n**提交记录**:\n{change_log if change_log else '无提交记录'}"
                }
            },
            {
                "tag": "img",
                "img_key": image_key,
                "alt": {"tag": "plain_text", "content": "扫码下载"}
            }
        ]
    }

    payload = {
        "receive_id": chat_id,
        "msg_type": "interactive",
        "content": json.dumps(card_content)
    }

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        result = response.json()
        if result.get("code") == 0:
            print("Message sent successfully")
        else:
            raise Exception(f"Failed to send message: {result.get('msg')}")
    else:
        raise Exception(f"HTTP error: {response.status_code}")

def upload_mapping_file(bucket):
    """上传 mapping.txt 文件到 OSS"""
    mapping_file_path = f'/root/.jenkins/workspace/{job_name}/app/mapping.txt'
    if os.path.exists(mapping_file_path):
        oss_filename = f'{build_time}-mapping.txt'
        result = bucket.put_object_from_file(f'hotcoin/{oss_filename}', mapping_file_path)
        if result.status == 200:
            print(f"mapping.txt 文件上传成功: https://{BUCKET_NAME}.oss-cn-hongkong.aliyuncs.com/hotcoin/{oss_filename}")
        else:
            print("mapping.txt 文件上传失败")
    else:
        print("mapping.txt 文件不存在，跳过上传。")

def upload_oss_and_send():
    """上传 APK 文件和二维码图片到 OSS 并发送消息到飞书"""
    auth = oss2.Auth('LTAI5tAd9TVi5Hu8LoB6oyNy', 'YsnU3ceRUjs2Edh9a7BXVA2eCRNKQU')
    bucket = oss2.Bucket(auth, OSS_ENDPOINT, BUCKET_NAME)

    if not os.path.exists(path):
        print(f"Path not found: {path}")
        return

    message_payload = None  # 用于存储消息内容

    for filename in os.listdir(path):
        if filename.endswith(".apk"):
            oss_filename = f'{build_time}-{filename}'
            download_url = f'https://{BUCKET_NAME}.oss-cn-hongkong.aliyuncs.com/hotcoin/{oss_filename}'
            result = bucket.put_object_from_file(f'hotcoin/{oss_filename}', f'{path}/{filename}')
            if result.status == 200:
                print(f"APK 文件上传成功: {download_url}")

                # 生成二维码
                qr_image_path = "/data/scripts/qr_code.jpg"
                img = qrcode.make(data=download_url)
                img.save(qr_image_path)

                # 上传二维码图片到OSS
                oss_img_filename = f'{build_time}-{filename}.jpg'
                img_result = bucket.put_object_from_file(f'hotcoin/{oss_img_filename}', qr_image_path)
                if img_result.status == 200:
                    print(f"二维码图片上传成功: https://{BUCKET_NAME}.oss-cn-hongkong.aliyuncs.com/hotcoin/{oss_img_filename}")

                    # 准备消息内容
                    token = get_tenant_access_token(APP_ID, APP_SECRET)
                    image_key = upload_image_from_url_to_lark(f'https://{BUCKET_NAME}.oss-cn-hongkong.aliyuncs.com/hotcoin/{oss_img_filename}', token)
                    message_payload = {
                        "image_key": image_key,
                        "download_url": download_url
                    }
                else:
                    print("二维码图片上传失败")
            else:
                print("APK 文件上传失败")

    if build_type.lower() == 'release':
        upload_mapping_file(bucket)  # 在上传 APK 后调用

    # 统一在函数最后发送消息
    if message_payload:
        send_interactive_message_with_info(
            chat_id=CHAT_ID,
            access_token=get_tenant_access_token(APP_ID, APP_SECRET),
            image_key=message_payload["image_key"],
            job_name=job_name,
            branch=branch,
            build_id=build_id,
            build_type=build_type,
            job_url=job_url,
            download_url=message_payload["download_url"],
            change_log=change_log
        )

if __name__ == "__main__":
    try:
        upload_oss_and_send()
    except Exception as e:
        print(f"Error in main execution: {e}")