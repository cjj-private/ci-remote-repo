import re
with open('logs/access.log') as f:
    text = f.read()

lst = re.findall(r'email:\w+@llpp33.top', text)
s = set(lst)

print(s, len(s))
