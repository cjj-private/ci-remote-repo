# 21日新版发布流程
# ——————准备流程——————
1. tg配置nacos,执行sql脚本；（baylee,roy，已完成）
2. 找到所有需要发布的服务的回滚镜像，分别编辑好永续和交割服务的回滚脚本；（jackie,已完成）
3. 修改流水线，使用jdk17进行编译，取消发布step；（bob，进行中）
4. 生成所有需要发布的永续和交割的新镜像；（bob，进行中）
5. 按启动顺序分别编写永续和交割的发布命令；（jackie，进行中）
6. 按停止顺序分别编写永续和交割的停止命令；（jackie，已完成）
7. 修改hazelcase服务yaml文件的启动定制参数（包含perp & deliver 共4个服务），并准备好启动和停止的命令；(bob,待处理)
8. xxjob配置；（roy,已完成）
9. nacos配置；（roy,已完成）
10. kafka启动脚本准备；（bob,roy,待处理）
 
# ——————合约-发布流程(jackie)——————
1. 执行停止永续合约交易的脚本，脚本如下；
 <br/>进入perpetual库，停止所有合约交易
```
 update currency_pair set status = 2;
```
2. 停止服务顺序按simon指导，脚本如下；
```
kubectl scale deploy newex-perpetual-matching-deployment --replicas=0
kubectl scale deploy newex-perpetual-event-deployment --replicas=0
kubectl scale deploy newex-perpetual-scheduler-deployment --replicas=0
kubectl scale deploy newex-perpetual-openapi-deployment --replicas=0
kubectl scale deploy newex-perpetual-rest-deployment --replicas=0
 ```
3. 观察kafka的消费完成（simon确认），修改系统参数，重启3个服务(bob)；启动脚本如下；<br/>
     3.1 观察3个kafka节点的user相关的channel的数据消费值为0；Message consume per minute 数值达到0；<br/>
     3.2 kafka配置已添加待重启kafka01和kafka03，待执行以下命令；
     ```
     systemctl daemon-reload && systemctl restart kafka
     ```
4. 停永续的dbsync服务;
```
kubectl scale deploy newex-perpetual-dbsync-deployment --replicas=0
```
5. 停永续的hazelcast的2个服务；
```
kubectl scale deploy newex-hazelcast --replicas=0
kubectl scale deploy newex-hazelcast-mimic --replicas=0
```
6. 执行数据同步脚本；（roy）
（永续：perpetual库）
<br/>
select concat('update ', table_name, ' set principal_open_margin = open_margin, principal_fee = avg_fee * amount;') 
from information_schema.tables where table_schema = 'perpetual'
and table_name like 'order_%' 
and table_name not like 'order_finish%'
and table_name not like 'order_history%'
and table_name != 'order_condition'
and table_name != 'order_all' 
and table_name != 'order_adjust_log';
<br/>执行生成的脚本


7. 启动永续的2个hazelcase服务，脚本如下;
```
kubectl --kubeconfig=/root/.kube/config apply -f  /data/scripts/yaml/newex-hazelcast/newex-hazelcast.yaml
kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-hazelcast-mimic/newex-hazelcast-mimic.yaml
```
8. 按永续发布顺序执行准备好的发布命令，脚本如下;
 <br/>发布永续服务 （两个为一组发布）
```
kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-perpetual/newex-perpetual-rest.yaml
kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-perpetual/newex-perpetual-rest-web.yaml

kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-perpetual/newex-perpetual-dbsync.yaml
kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-perpetual/newex-perpetual-matching.yaml

kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-perpetual/newex-perpetual-event.yaml
kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-perpetual/newex-perpetual-scheduler.yaml
kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-perpetual/newex-perpetual-openapi.yaml

kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-streaming-rest/newex-streaming-rest.yaml
kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/integration/integration-rest.yaml
```

9. 发布其他服务（两个为一组发布）（***合约和交割核心服务都启动完成后）

```
kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-push/newex-push.yaml
kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/newex-push/newex-push-web.yaml

kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/hotcoin/agent/new-agent.yaml

kubectl --kubeconfig=/root/.kube/config apply -f /data/scripts/yaml/contract/newex-analysis-job.yaml
kubectl --kubeconfig=/root/.kube/config  apply -f /data/scripts/yaml/contract/newex-analysis-rest.yaml

kubectl --kubeconfig=/root/.kube/new-cluster-config apply -f /data/scripts/yaml/new-cluster/service-manage-jumper.yaml
kubectl --kubeconfig=/root/.kube/new-cluster-config apply -f /data/scripts/yaml/new-cluster/service-manage-api.yaml
```

10. 检查资金（simon），标志性状态如下；

11. 执行开启交易脚本，脚本如下；
<br/>进入perpetual的库，执行以下脚本，打开量化交易 
```
update currency_pair set status = 1;
```
打开用户交易 
```
update currency_pair set status = 0;
```
12. 测试基本功能；（测试组）
 
# ——————合约-回滚流程——————
1. 重复以上的停止服务流程；
2. 按序执行回滚服务命令；
<br/>[回滚链接](http://10.0.0.88/jackie/ops-docs-jackie/-/blob/master/%E5%8F%91%E7%89%88.md?ref_type=heads)
3. 检查回滚情况，标志性状态如下；（roy,simon,keneth）
 
# ——————交割-发布流程（同步合约发布，kafka共享）——————
1. 执行停止交割合约交易的脚本，脚本如下；
 <br/>进入deliver库，停止所有交割合约交易
```
 update currency_pair set status = 2;
```
2. 执行停止交割合约交易的脚本，脚本如下；
```
kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-matching --replicas=0
kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-event --replicas=0
kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-scheduler --replicas=0
kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-openapi --replicas=0
kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-rest --replicas=0
 ```
3. 观察kafka的消费完成；
     观察3个kafka节点的user相关的channel的数据消费值为0；
4. 停止交割dbsync服务
```
kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-dbsync --replicas=0
```
5. 停交割的hazelcast的2个服务；
```
kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-hazelcast-deliver --replicas=0
kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-hazelcast-deliver-mimic --replicas=0
```

6. 执行数据同步脚本；deliver库
<br/>
select concat('update ', table_name, ' set principal_open_margin = open_margin, principal_fee = avg_fee * amount;') 
from information_schema.tables where table_schema = 'deliver'
and table_name like 'order_%' 
and table_name not like 'order_finish%'
and table_name not like 'order_history%'
and table_name != 'order_condition'
and table_name != 'order_all' 
and table_name != 'order_adjust_log';
<br/>执行生成的脚本

7. 启动永续的2个hazelcase服务，脚本如下;
```
kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-hazelcast-deliver.yaml
kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-hazelcast-deliver-mimic.yaml
```
8. 按交割发布顺序执行准备好的发布命令，脚本如下;
```
kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-deliver-rest.yaml
kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-deliver-dbsync.yaml
kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-deliver-matching.yaml

kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-deliver-event.yaml
kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-deliver-scheduler.yaml

kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-deliver-openapi.yaml
kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-streaming-deliver-rest.yaml
```

9. 发布其他服务（***合约和交割核心服务都启动完成后）
```
kubectl --kubeconfig=/root/.kube/deliver apply -f /data/scripts/yaml/deliver/newex-portal.yaml
```

9. 检查资金（simon），标志性状态如下；
10. 执行开启交易脚本，脚本如下；
进入deliver的库，执行以下脚本，打开量化交易 
```
update currency_pair set status = 1;
```
打开用户交易 
```
update currency_pair set status = 0;
```
10. 测试基本功能；（测试组）
 
# ——————永续-回滚流程——————
1. 重复以上的停止服务流程；
2. 按序执行回滚服务命令；
```
kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy newex-hazelcast-deliver --to-revision=1
---->kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-hazelcast-deliver --replicas=3
kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy newex-hazelcast-deliver-mimic --to-revision=5
---->kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-hazelcast-deliver-mimic --replicas=3

kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy  newex-deliver-rest --to-revision=36
---->kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-rest --replicas=2

kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy newex-deliver-dbsync --to-revision=6
---->kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-dbsync --replicas=2

kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy  newex-deliver-matching --to-revision=17
--->kubectl --kubeconfig=/root/.kube/deliver   scale deploy newex-deliver-matching  --replicas=4

kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy newex-deliver-event  --to-revision=20
--->kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-event --replicas=2

kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy newex-deliver-scheduler --to-revision=31
---->kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-scheduler --replicas=2

kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy  newex-deliver-openapi --to-revision=18
---->kubectl --kubeconfig=/root/.kube/deliver scale deploy newex-deliver-openapi --replicas=2

kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy newex-streaming-deliver-rest --to-revision=3

kubectl --kubeconfig=/root/.kube/deliver rollout undo deploy  newex-portal --to-revision=14
```
2. 检查回滚情况，标志性状态如下；（roy,simon,keneth）
 
 
# 时间线（8月21日，凌晨）：
3点开始：1个小时，发合约、永续（同步分别发布）；（最快30分钟）<br/>
3:30点测试合约、永续<br/>
测试结果：<br/>
异常：开始回滚；暂停后续发布；<br/>
正常：开始发布交割：<br/>
 <br/>
测试结果：<br/>
异常：开始回滚；暂停后续发布；<br/>
正常：开始发布交割：<br/>
4点开始：1个小时，发现货；<br/>
5点开始发web（all）；master分支<br/>