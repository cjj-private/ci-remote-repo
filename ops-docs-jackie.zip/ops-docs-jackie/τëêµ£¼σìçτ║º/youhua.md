### 生产环境各个deployment部署细节下载地址[点击下载](http://10.0.0.88/jackie/ops-docs-jackie/-/blob/master/%E7%89%88%E6%9C%AC%E5%8D%87%E7%BA%A7/deployment.zip)
### 合约部分可能增加的类似优化
```
        env:
        - name: NacosServiceName
          value: newex-dax-asset
        - name: POD_IP
          valueFrom:
            fieldRef:
              fieldPath: status.podIP
        lifecycle:
          preStop:
            exec:
              command: ['sh', '-c', 'curl -f -X PUT "http://192.168.125.107:30848/nacos/v1/ns/instance?serviceName=$NacosServiceName&ip=$POD_IP&port=7001&enabled=false";sleep 60']
spec:
  spec:
    terminationGracePeriodSeconds: 60
```
### 滚动更新影响的服务 可能有影响的服务请帮忙标注一下 ✅ ,默认是不影响 

### 合约
| 服务 | 有影响 | 不影响 |
| --- | --- | --- |
| hazelcast-management | [ ] | [ ] |
| integration-rest-deployment | [ ] | [ ] |
| newex-analysis-job | [ ] | [ ] |
| newex-analysis-rest | [ ] | [ ] |
| newex-asset-deployment | [ ] | [ ] |
| newex-boss-deployment | [ ] | [ ] |
| newex-hazelcast | [✅] | [ ] |
| newex-hazelcast-mimic | [✅] | [ ] |
| newex-market-event-deployment | [ ] | [ ] |
| newex-market-rest-deployment | [ ] | [ ] |
| newex-market-scheduler-deployment | [ ] | [ ] |
| newex-market-spider-deployment | [ ] | [ ] |
| newex-market-spider-pair-code | [ ✅] | [ ] |
| newex-perpetual-dbsync-deployment | [ ✅] | [ ] |
| newex-perpetual-event-deployment | [ ] | [ ] |
| newex-perpetual-matching-deployment | [✅ ] | [ ] |
| newex-perpetual-matching-mimic-deployment | [✅ ] | [ ] |
| newex-perpetual-openapi-deployment | [ ✅] | [ ] |
| newex-perpetual-openapi-gray | [ ] | [ ] |
| newex-perpetual-openapi-mimic | [ ] | [ ] |
| newex-perpetual-rest-deployment | [ ✅] | [ ] |
| newex-perpetual-rest-web | [✅ ] | [ ] |
| newex-perpetual-scheduler-deployment | [ ] | [ ] |
| newex-push-deployment | [✅ ] | [ ] |
| newex-push-web-deployment | [ ✅] | [ ] |
| newex-scheduler-deployment | [ ] | [ ] |
| newex-streaming-rest-deployment | [ ] | [ ] |
| newex-users-rest-deployment | [✅ ] | [ ] |

### 现货
| 服务 | 有影响 | 不影响 |
| --- | --- | --- |
| bark-server-appstore | [ ] | [ ] |
| bark-server-enterprise | [ ] | [ ] |
| datax-executor | [ ] | [ ] |
| datax-web | [ ] | [ ] |
| hiatpay-api | [ ] | [ ] |
| kline-his-generator-0 | [ ] | [ ] |
| kline-his-generator-1 | [ ] | [ ] |
| lp-hotcoin-auth-service | [ ] | [ ] |
| lp-hotcoin-data-service | [ ] | [ ] |
| lp-hotcoin-druid-admin | [ ] | [ ] |
| lp-hotcoin-gateway-greatwall | [ ] | [ ] |
| notice-batch-server | [ ] | [ ] |
| notice-server | [ ] | [ ] |
| otc-chat-jobs | [ ] | [ ] |
| outermarket-aggregator-event | [ ] | [ ] |
| outermarket-aggregator-rest | [ ] | [ ] |
| outermarket-aggregator-spider | [ ] | [ ] |
| service-accserver | [ ] | [ ] |
| service-activity | [ ] | [ ] |
| service-adapter | [ ] | [ ] |
| service-admin | [ ] | [ ] |
| service-admin-layui | [ ] | [ ] |
| service-ali-sentinel | [ ] | [ ] |
| service-bigdata | [ ] | [ ] |
| service-capital | [ ] | [ ] |
| service-coin | [✅] | 通知客服停止审核 |
| service-commission | [ ] | [ ] |
| service-config-center | [ ] | [ ] |
| service-entrust | [ ] | [ ] |
| service-entrustcancel | [ ] | [ ] |
| service-fa-admin | [ ] | [ ] |
| service-fa-event | [ ] | [ ] |
| service-fa-order | [ ] | [ ] |
| service-fa-product | [ ] | [ ] |
| service-fa-settle | [ ] | [ ] |
| service-frcs-rule | [ ] | [ ] |
| service-hkweb | [ ] | [ ] |
| service-increment-job | [ ] | [ ] |
| service-ip-api | [ ] | [ ] |
| service-jinpinggateway | [ ] | [ ] |
| service-job | [✅] | 凌晨0点至次日8点禁止发布或重启，盈亏分析任务，如有重启或发布，需要重新执行任务 |
| service-kline | [ ] | [ ] |
| service-kline-history | [ ] | [ ] |
| service-mag-liquidation | [ ] | [ ] |
| service-mag-margin | [ ] | [ ] |
| service-mag-scheduler | [ ] | [ ] |
| service-manage-api | [ ] | [ ] |
| service-manage-jumper | [✅] |通知客服停止审核|
| service-market | [✅] | 影响K线，需要重启service-websocket-gateway及ws-gateway-app|
| service-market-calculate | [ ] | [ ] |
| service-match-1 | [ ] | [ ] |
| service-match-10 | [ ] | [ ] |
| service-match-11 | [ ] | [ ] |
| service-match-12 | [ ] | [ ] |
| service-match-13 | [ ] | [ ] |
| service-match-14 | [ ] | [ ] |
| service-match-15 | [ ] | [ ] |
| service-match-16 | [ ] | [ ] |
| service-match-17 | [ ] | [ ] |
| service-match-18 | [ ] | [ ] |
| service-match-19 | [ ] | [ ] |
| service-match-2 | [ ] | [ ] |
| service-match-20 | [ ] | [ ] |
| service-match-21 | [ ] | [ ] |
| service-match-22 | [ ] | [ ] |
| service-match-23 | [ ] | [ ] |
| service-match-24 | [ ] | [ ] |
| service-match-25 | [ ] | [ ] |
| service-match-26 | [ ] | [ ] |
| service-match-27 | [ ] | [ ] |
| service-match-28 | [ ] | [ ] |
| service-match-29 | [ ] | [ ] |
| service-match-3 | [ ] | [ ] |
| service-match-30 | [ ] | [ ] |
| service-match-31 | [ ] | [ ] |
| service-match-32 | [ ] | [ ] |
| service-match-33 | [ ] | [ ] |
| service-match-34 | [ ] | [ ] |
| service-match-35 | [ ] | [ ] |
| service-match-36 | [ ] | [ ] |
| service-match-37 | [ ] | [ ] |
| service-match-38 | [ ] | [ ] |
| service-match-39 | [ ] | [ ] |
| service-match-4 | [ ] | [ ] |
| service-match-40 | [ ] | [ ] |
| service-match-5 | [ ] | [ ] |
| service-match-6 | [ ] | [ ] |
| service-match-7 | [ ] | [ ] |
| service-match-8 | [ ] | [ ] |
| service-match-9 | [ ] | [ ] |
| service-matchsync | [ ] | [ ] |
| service-matchsync-0 | [ ] | [ ] |
| service-matchsync-1 | [ ] | [ ] |
| service-matchsync-2 | [ ] | [ ] |
| service-matchsync-3 | [ ] | [ ] |
| service-matchsync-4 | [ ] | [ ] |
| service-matchsync-5 | [ ] | [ ] |
| service-matchsync-6 | [ ] | [ ] |
| service-matchsync-7 | [ ] | [ ] |
| service-matchsync-8 | [ ] | [ ] |
| service-matchsync-9 | [ ] | [ ] |
| service-nft | [ ] | [ ] |
| service-notification | [ ] | [ ] |
| service-oss | [ ] | [ ] |
| service-otc | [ ] | [ ] |
| service-otcapi | [ ] | [ ] |
| service-planentrust | [ ] | [ ] |
| service-quant-deadman-switch | [ ] | [ ] |
| service-quantitative | [ ] | [ ] |
| service-rewardhub | [ ] | [ ] |
| service-user | [✅] | 中午11点50至12点30分禁止发布或重启，返佣任务，如有重启或发布，需要重新执行任务|
| service-websocket-gateway | [ ] | [ ] |
| service-websocket-gateway-api | [ ] | [ ] |
| service-websocket-prepose | [ ] | [ ] |
| starry-insight-api | [ ] | [ ] |
| starry-insight-ui | [ ] | [ ] |
| ws-gateway-app | [ ] | [ ] |


### 交割
| 服务 | 有影响 | 不影响 |
| --- | --- | --- |
| canal-deliver | [ ] | [ ] |
| canal-deliver-launcher | [ ] | [ ] |
| hazelcast-management | [ ] | [ ] |
| newex-deliver-dbsync | [ ] | [ ] |
| newex-deliver-event | [ ] | [ ] |
| newex-deliver-matching | [✅ ] | [ ] |
| newex-deliver-matching-mimic | [✅ ] | [ ] |
| newex-deliver-openapi | [ ] | [ ] |
| newex-deliver-openapi-mimic | [ ] | [ ] |
| newex-deliver-rest | [✅ ] | [ ] |
| newex-deliver-scheduler | [ ] | [ ] |
| newex-hazelcast-deliver | [✅ ] | [ ] |
| newex-hazelcast-deliver-mimic | [ ✅] | [ ] |
| newex-perpetual-openapi-deployment | [ ] | [ ] |
| newex-portal | [✅ ] | [ ] |
| newex-streaming-deliver-rest | [ ] | [ ] |