# gitlab 升级
````
了解gitlab upgrade path
https://gitlab-com.gitlab.io/support/toolbox/upgrade-path/?current=12.2.12

下载所有的安装包
安装安装路径执行如下
例如：yum install ./gitlab-ce-15.0.5-ce.0.el7.x86_64.rpm 

创建一个项目来测试 
git pull, git push ,merge等操作


````

#  问题
````
有一些不兼容需要删除
查询不兼容数据
gitlab-psql -c "SELECT job_class_name, table_name, column_name, job_arguments FROM batched_background_migrations WHERE status NOT IN(3, 6);"

删除不兼容数据，可能有多条，逐条删除
gitlab-rake gitlab:background_migrations:finalize[CopyColumnUsingBackgroundMigrationJob,taggings,id,'[["id", "taggable_id"], ["id_convert_to_bigint", "taggable_id_convert_to_b']


````
