 # 网络
[点击查看架构图](https://drive.google.com/file/d/1WOO1daz7oRl2y84j2EP0R3FIN9AGMsZF/view?usp=drive_link)
```
生产（新加坡）:
vpc-t4nb3paveau4stc8xxqrv（prod-network ）
网段:192.168.0.0/16
```


# 前端服务
```
主站域名 :www.hotcoin.com
主站手机端：m.hotcoin.com

备用域名：www.hotcoin.cc
        www.hotcoin.zone
        www.hotcoin.life

(管理后台)service_newadmin_web ：https://new-admin.yzcencv.com/

```

# k8s后端服务--->合约
```
命名空间        服务名字                                   服务类型        集群IP            外网ip             服务端口          
default       canal-deployer                            NodePort       172.25.140.85    <none>            11111:32569/TCP        
default       hazelcast-management                      NodePort       172.25.193.194   <none>            8080:32457/TCP        
default       integration-rest-service                  NodePort       172.25.224.157   <none>            7001:30701/TCP        
default       kline-his-generator                       NodePort       172.25.117.174   <none>            8087:30087/TCP        
default       kubernetes                                ClusterIP      172.25.0.1       <none>            443/TCP     
default       newex-asset                               NodePort       172.25.196.9     <none>            7001:30705/TCP,7003:30706/TCP      
default       newex-boss-service                        NodePort       172.25.14.158    <none>            7001:30908/TCP        
default       newex-hazelcast-mimic-svc                 NodePort       172.25.75.114    <none>            5777:31237/TCP     
default       newex-hazelcast-svc                       NodePort       172.25.150.78    <none>            5777:31713/TCP        
default       newex-market-event-service                ClusterIP      172.25.104.18    <none>            7001/TCP         
default       newex-market-rest-service                 NodePort       172.25.130.188   <none>            7001:31939/TCP        
default       newex-market-scheduler-service            NodePort       172.25.197.244   <none>            7001:32475/TCP        
default       newex-market-spider-pair-code-service     NodePort       172.25.65.138    <none>            7001:31477/TCP    
default       newex-market-spider-service               NodePort       172.25.222.209   <none>            7001:31633/TCP         
default       newex-perpetual-event-service             NodePort       172.25.157.17    <none>            7001:30832/TCP         
default       newex-perpetual-matching-mimic            NodePort       172.25.93.19     <none>            7001:31914/TCP         
default       newex-perpetual-openapi-mimic-service     ClusterIP      172.25.14.187    <none>            7001/TCP       
default       newex-perpetual-openapi-service           NodePort       172.25.149.22    <none>            7001:32521/TCP       
default       newex-perpetual-rest-service              NodePort       172.25.156.70    <none>            7001:30331/TCP        
default       newex-perpetual-rest-web-service          NodePort       172.25.237.218   <none>            7001:30332/TCP      
default       newex-perpetual-scheduler-service         NodePort       172.25.14.55     <none>            7001:32042/TCP,8080:30657/TCP    
default       newex-perpeture-maker-service             NodePort       172.25.26.147    <none>            7001:32324/TCP      
default       newex-push-service                        NodePort       172.25.75.63     <none>            8104:32312/TCP      
default       newex-push-web-service                    NodePort       172.25.176.162   <none>            8104:32315/TCP       
default       newex-scheduler-service                   NodePort       172.25.25.72     <none>            7001:30702/TCP      
default       newex-users-rest-service                  NodePort       172.25.26.100    <none>            7001:30907/TCP      
hotcoin       new-agent-h5                              NodePort       172.25.122.99    <none>            80:30311/TCP      
hotcoin       new-agent-service                         NodePort       172.25.132.114   <none>            8080:32046/TCP       
hotcoin       new-agent-web                             NodePort       172.25.19.227    <none>            80:30300/TCP        
hotcoin       new-agent-web01                           NodePort       172.25.118.136   <none>            80:30301/TCP     


kube-system   ack-node-local-dns-admission-controller   NodePort       172.25.77.100    <none>            443:30217/TCP       
kube-system   agent-ingress-slb-wangsu                  LoadBalancer   172.25.245.122   47.236.225.172    443:32447/TCP,80:31058/TCP      
kube-system   aws-contract-ingress                      LoadBalancer   172.25.74.168    47.237.93.39      80:30444/TCP,443:31510/TCP     
kube-system   cstream-chbxj-ingress                     LoadBalancer   172.25.67.1      8.222.253.255     80:32441/TCP,443:30835/TCP     
kube-system   cstream-hcinterface-top                   LoadBalancer   172.25.225.81    47.236.79.243     80:31231/TCP,443:30764/TCP     
kube-system   cstream-hotcoingex                        LoadBalancer   172.25.140.112   8.219.76.218      80:32130/TCP,443:30999/TCP     
kube-system   heapster                                  ClusterIP      172.25.86.223    <none>            80/TCP      
kube-system   ingress-nginx-controller-admission        ClusterIP      172.25.22.237    <none>            443/TCP       
kube-system   internal-ingress                          LoadBalancer   172.25.16.61     192.168.123.119   80:32525/TCP,443:30644/TCP      
kube-system   kube-dns                                  ClusterIP      172.25.0.10      <none>            53/UDP,53/TCP,9153/TCP    
kube-system   kubelet                                   ClusterIP      None             <none>            10250/TCP       
kube-system   logtail-statefulset                       ClusterIP      172.25.155.83    <none>            4040/TCP,18689/TCP,11800/TCP,21800/TCP 
kube-system   metrics-server                            ClusterIP      172.25.200.8     <none>            443/TCP      
kube-system   new-ingress-lb                            LoadBalancer   172.25.136.113   8.214.79.123      80:30788/TCP,443:32394/TCP       
kube-system   new-wss-lb                                LoadBalancer   172.25.29.201    47.245.112.95     80:30441/TCP,443:30193/TCP        
kube-system   nginx-ingress-lb                          LoadBalancer   172.25.19.178    47.241.177.33     80:31139/TCP,443:32479/TCP     
kube-system   prod-api-ingress-lb                       LoadBalancer   172.25.26.11     8.219.122.45      80:32695/TCP,443:32624/TCP    
kube-system   ruisu-wss                                 LoadBalancer   172.25.128.64    8.219.99.174      80:31693/TCP,443:32366/TCP     
kube-system   sls-kube-state-metrics                    ClusterIP      172.25.191.195   <none>            8080/TCP      
kube-system   storage-crd-validate-service              ClusterIP      172.25.230.111   <none>            443/TCP     
kube-system   storage-monitor-service                   ClusterIP      172.25.57.6      <none>            11280/TCP     
logging       fluentd-err-filter-aggregator             ClusterIP      172.25.97.57     <none>            9880/TCP,24224/TCP     
logging       fluentd-err-filter-forwarder              ClusterIP      172.25.12.158    <none>            9880/TCP     
logging       fluentd-err-filter-headless               ClusterIP      None             <none>            9880/TCP,24224/TCP    
logging       mongo                                     NodePort       172.25.44.211    <none>            27017:31134/TCP     
logging       weblog                                    NodePort       172.25.131.188   <none>            5000:32328/TCP
arms-pilot    arms-pilot-ack-arms-pilot                 ClusterIP      172.25.78.123    <none>            443/TCP         
arms-prom     arms-prom-admin                           ClusterIP      172.25.11.72     <none>            9335/TCP        
arms-prom     arms-prom-server                          ClusterIP      172.25.142.36    <none>            9090/TCP         
arms-prom     kube-state-metrics                        ClusterIP      172.25.192.233   <none>            8080/TCP,8081/TCP       
arms-prom     node-exporter                             ClusterIP      None             <none>            9100/TCP        
arms-prom     node-gpu-exporter                         ClusterIP      172.25.75.148    <none>            9445/TCP   


```

# k8s后端服务--->交割
```
命名空间       服务名字                                    服务类型        集群ip            外部ip          服务端口 
default       canal-deliver                             ClusterIP      172.16.121.187   <none>          8080/TCP,11111/TCP      
default       hazelcast-management                      NodePort       172.16.125.20    <none>          8080:31691/TCP    
default       kubernetes                                ClusterIP      172.16.0.1       <none>          443/TCP     
default       newex-deliver-openapi                     NodePort       172.16.19.67     <none>          7001:30338/TCP      
default       newex-deliver-openapi-mimic               NodePort       172.16.10.172    <none>          7001:30336/TCP   
default       newex-deliver-rest                        NodePort       172.16.8.162     <none>          7001:30331/TCP     
default       newex-hazelcast-deliver-mimic-svc         ClusterIP      172.16.142.142   <none>          5777/TCP      
default       newex-hazelcast-deliver-svc               ClusterIP      172.16.180.206   <none>          5777/TCP      


arms-prom     arms-prom-admin                           ClusterIP      172.16.193.34    <none>          9335/TCP   
arms-prom     arms-prom-server                          ClusterIP      172.16.193.66    <none>          9090/TCP      
arms-prom     kube-state-metrics                        ClusterIP      172.16.246.178   <none>          8080/TCP,8081/TCP    
arms-prom     node-exporter                             ClusterIP      None             <none>          9100/TCP      
arms-prom     node-gpu-exporter                         ClusterIP      172.16.227.101   <none>          9445/TCP  
kube-system   ack-node-local-dns-admission-controller   ClusterIP      172.16.23.42     <none>          443/TCP     
kube-system   cnfs-cache-ds-service                     ClusterIP      172.16.6.160     <none>          6500/TCP   
kube-system   heapster                                  ClusterIP      172.16.15.22     <none>          80/TCP     
kube-system   ingress-nginx-controller-admission        ClusterIP      172.16.18.40     <none>          443/TCP     
kube-system   internal-ingress                          LoadBalancer   172.16.62.48     192.168.1.181   80:31873/TCP,443:31675/TCP
kube-system   kube-dns                                  ClusterIP      172.16.0.10      <none>          53/UDP,53/TCP,9153/TCP  
kube-system   kubelet                                   ClusterIP      None             <none>          10250/TCP      
kube-system   logtail-statefulset                       ClusterIP      172.16.165.83    <none>          4040/TCP,18689/TCP,11800/TCP,21800/TCP
kube-system   metrics-server                            ClusterIP      172.16.11.10     <none>          443/TCP     
kube-system   nginx-ingress-lb                          LoadBalancer   172.16.37.199    47.236.53.44    80:31241/TCP,443:30232/TCP  
kube-system   sls-kube-state-metrics                    ClusterIP      172.16.44.180    <none>          8080/TCP     
kube-system   storage-crd-validate-service              ClusterIP      172.16.238.22    <none>          443/TCP   
kube-system   storage-monitor-service                   ClusterIP      172.16.113.105   <none>          11280/TCP       
logging       fluentd-err-filter-aggregator             ClusterIP      172.16.24.99     <none>          9880/TCP,24224/TCP      
logging       fluentd-err-filter-forwarder              ClusterIP      172.16.113.236   <none>          9880/TCP     
logging       fluentd-err-filter-headless               ClusterIP      None             <none>          9880/TCP,24224/TCP   

```

# k8s后端服务--->现货
```
命令空间       服务                                                服务类型        集群ip           外部ip            服务端口                                   
default       app-log-svc                                        ClusterIP      172.16.3.187     <none>            80/TCP                             
default       bark-server-appstore                               NodePort       172.16.15.42     <none>            8080:30888/TCP                            
default       bark-server-enterprise                             NodePort       172.16.219.63    <none>            8080:30999/TCP                           
default       chat-server                                        ClusterIP      None             <none>            9199/TCP,8443/TCP                        
default       chat-server-svc                                    NodePort       172.16.131.144   <none>            9199:30685/TCP,8443:31536/TCP          
default       datax-admin                                        NodePort       172.16.25.81     <none>            9527:30010/TCP                         
default       global-hotcoinex-web                               ClusterIP      172.16.61.98     <none>            80/TCP                      
default       h5-part-new                                        ClusterIP      172.16.109.129   <none>            80/TCP                        
default       hiatpay-api                                        ClusterIP      172.16.153.161   <none>            8080/TCP                               
default       hotcoin-web                                        ClusterIP      172.16.61.219    <none>            80/TCP                         
default       hotcoinex-web                                      ClusterIP      172.16.167.233   <none>            80/TCP                       
default       kline-his-generator                                NodePort       172.16.154.122   <none>            8087:30087/TCP              
default       kubernetes                                         ClusterIP      172.16.0.1       <none>            443/TCP                           
default       lp-hotcoin-auth-service                            NodePort       172.16.79.5      <none>            8080:32649/TCP                          
default       lp-hotcoin-druid-admin                             NodePort       172.16.39.27     <none>            8080:31316/TCP                   
default       lp-hotcoin-gateway-greatwall                       NodePort       172.16.244.247   <none>            8080:30018/TCP,8888:31825/TCP            
default       m-hotcoin-web                                      ClusterIP      172.16.108.34    <none>            80/TCP                             
default       new-admin-web                                      ClusterIP      172.16.151.58    <none>            80/TCP                      
default       newadmin-web                                       ClusterIP      172.16.134.44    <none>            80/TCP                         
default       notice-server                                      NodePort       172.16.147.172   <none>            8989:31089/TCP                              
default       otc-chat-jobs                                      ClusterIP      172.16.78.161    <none>            7001/TCP,9091/TCP                     
default       outermarket-aggregator-event                       ClusterIP      172.16.103.23    <none>            8080/TCP                              
default       outermarket-aggregator-rest                        ClusterIP      172.16.236.165   <none>            8080/TCP                        
default       outermarket-aggregator-spider                      ClusterIP      172.16.127.245   <none>            8080/TCP                            
default       perpetual-rest-web                                 ClusterIP      172.16.183.32    <none>            80/TCP                                   
default       service-admin-layui                                NodePort       172.16.180.89    <none>            8080:31001/TCP                               
default       service-ali-sentinel                               NodePort       172.16.180.107   <none>            8080:30851/TCP,8719:32152/TCP                    
default       service-coin                                       NodePort       172.16.242.35    <none>            8080:30100/TCP                         
default       service-config-center                              ClusterIP      172.16.44.54     <none>            8080/TCP                         
default       service-fa-admin                                   ClusterIP      172.16.223.189   <none>            8080/TCP                               
default       service-fa-event                                   ClusterIP      172.16.21.48     <none>            8080/TCP                           
default       service-fa-order                                   ClusterIP      172.16.215.144   <none>            8080/TCP                                
default       service-fa-product                                 ClusterIP      172.16.84.153    <none>            8080/TCP                                
default       service-fa-settle                                  ClusterIP      172.16.187.41    <none>            8080/TCP                                
default       service-hkweb                                      NodePort       172.16.245.203   <none>            8080:30002/TCP,8888:31604/TCP                         
default       service-ip-api                                     ClusterIP      172.16.77.207    <none>            8080/TCP                                
default       service-jinpinggateway                             NodePort       172.16.37.142    <none>            8080:31000/TCP,8888:30853/TCP           
default       service-kline-history                              NodePort       172.16.70.0      <none>            8080:30666/TCP                         
default       service-manage-api                                 NodePort       172.16.15.164    <none>            8080:30187/TCP                      
default       service-matchsymc-svc                              NodePort       172.16.144.19    <none>            80:30119/TCP                  
default       service-oss                                        NodePort       172.16.125.196   <none>            8080:30180/TCP                             
default       service-otcapi                                     NodePort       172.16.137.152   <none>            8080:30808/TCP,20880:32365/TCP                 
default       service-quantitative-gray-svc                      NodePort       172.16.20.236    <none>            80:30099/TCP                           
default       service-quantitative-svc                           NodePort       172.16.44.192    <none>            80:30091/TCP                        
default       service-validate                                   ClusterIP      172.16.109.248   <none>            8989/TCP                          
default       service-websocket-gateway                          NodePort       172.16.20.207    <none>            8081:31626/TCP                        
default       service-websocket-gateway-api                      NodePort       172.16.183.137   <none>            8081:31349/TCP,8080:31350/TCP,8888:30507/TCP            
default       sureroute                                          ClusterIP      172.16.134.252   <none>            80/TCP                           
default       web-cc                                             ClusterIP      172.16.74.139    <none>            80/TCP                           
default       web-h5-cc                                          ClusterIP      172.16.20.141    <none>            80/TCP                      
default       ws-gateway-app                                     NodePort       172.16.106.98    <none>            8081:31329/TCP  


infra         apollo                                             NodePort       172.16.82.62     <none>            8070:31893/TCP,8080:32189/TCP              
infra         fluentd-err-filter-aggregator                      ClusterIP      172.16.57.66     <none>            9880/TCP,24224/TCP                      
infra         fluentd-err-filter-forwarder                       ClusterIP      172.16.188.100   <none>            9880/TCP                    
infra         fluentd-err-filter-headless                        ClusterIP      None             <none>            9880/TCP,24224/TCP          
infra         mongo                                              NodePort       172.16.126.160   <none>            27017:32377/TCP                             
infra         shardingsphere-ui                                  NodePort       172.16.219.145   <none>            8088:32668/TCP                             
infra         weblog                                             NodePort       172.16.166.64    <none>            5000:32328/TCP                       
infra         zookeeper                                          NodePort       172.16.183.252   <none>            2181:30513/TCP,2888:31400/TCP,3888:30130/TCP                  
infra         zookeeper-headless                                 ClusterIP      None             <none>            2181/TCP,2888/TCP,3888/TCP                                    
kube-system   ack-node-local-dns-admission-controller            NodePort       172.16.104.248   <none>            443:30941/TCP                              
kube-system   ack-prometheus-operator-coredns                    ClusterIP      None             <none>            9153/TCP                             
kube-system   ack-prometheus-operator-kube-controller-manager    ClusterIP      None             <none>            10252/TCP                         
kube-system   ack-prometheus-operator-kube-scheduler             ClusterIP      None             <none>            10251/TCP                      
kube-system   ack-prometheus-operator-kubelet                    ClusterIP      None             <none>            10250/TCP,10255/TCP,4194/TCP                           
kube-system   aws-spot-ingress                                   LoadBalancer   172.16.76.151    47.236.51.180     80:32174/TCP,443:30878/TCP                      
kube-system   bin-hcinterface-top                                LoadBalancer   172.16.22.214    47.237.64.199     80:32546/TCP,443:31789/TCP                  
kube-system   chbxj-xyz-ingress                                  LoadBalancer   172.16.146.229   47.236.161.26     80:31433/TCP,443:30398/TCP            
kube-system   dailishang-api-ingress                             LoadBalancer   172.16.150.153   8.219.200.161     443:32456/TCP             
kube-system   heapster                                           ClusterIP      172.16.82.22     <none>            80/TCP                                   
kube-system   hiatpay-ingress                                    LoadBalancer   172.16.153.48    8.219.141.113     443:31985/TCP                                
kube-system   hotcoingex-ingress                                 LoadBalancer   172.16.61.55     47.236.48.142     80:31154/TCP,443:31823/TCP                              
kube-system   ingress-admin                                      LoadBalancer   172.16.142.227   8.219.81.173      80:32753/TCP,443:31259/TCP                                   
kube-system   ingress-internal                                   LoadBalancer   172.16.4.164     192.168.124.250   80:32269/TCP,443:30890/TCP                              
kube-system   ingress-nginx-controller-admission                 ClusterIP      172.16.233.152   <none>            443/TCP                                    
kube-system   kube-dns                                           ClusterIP      172.16.0.10      <none>            53/UDP,53/TCP,9153/TCP                                    
kube-system   kubelet                                            ClusterIP      None             <none>            10250/TCP                                    
kube-system   lalc-ingress                                       LoadBalancer   172.16.54.180    8.219.121.83      80:31222/TCP,443:30113/TCP                                 
kube-system   lianghua-api-ingress                               LoadBalancer   172.16.126.5     8.219.84.136      443:32393/TCP                                    
kube-system   logtail-statefulset                                ClusterIP      172.16.115.191   <none>            4040/TCP,18689/TCP,11800/TCP,21800/TCP                     
kube-system   metrics-server                                     ClusterIP      172.16.196.100   <none>            443/TCP                                     
kube-system   nginx-ingress-lb                                   LoadBalancer   172.16.25.116    8.214.35.175      80:32196/TCP,443:30910/TCP                                  
kube-system   openapi-ingress-slb                                LoadBalancer   172.16.37.27     8.219.102.1       443:31303/TCP                                    
kube-system   ruisu-ingress                                      LoadBalancer   172.16.107.204   47.84.94.133      80:30434/TCP,443:31150/TCP                                 
kube-system   sls-kube-state-metrics                             ClusterIP      172.16.111.155   <none>            8080/TCP                                     
kube-system   storage-crd-validate-service                       ClusterIP      172.16.11.15     <none>            443/TCP                                     
kube-system   storage-monitor-service                            ClusterIP      172.16.157.85    <none>            11280/TCP                                     
kube-system   wangsu-ingress                                     LoadBalancer   172.16.17.102    47.237.11.46      443:31545/TCP,80:30342/TCP                                   
monitoring    ack-prometheus-operator-alertmanager               ClusterIP      172.16.121.34    <none>            9093/TCP                                  
monitoring    ack-prometheus-operator-grafana                    ClusterIP      172.16.138.70    <none>            80/TCP                                     
monitoring    ack-prometheus-operator-kube-state-metrics         ClusterIP      172.16.220.166   <none>            8080/TCP                                    
monitoring    ack-prometheus-operator-operator                   ClusterIP      172.16.53.255    <none>            443/TCP                                    
monitoring    ack-prometheus-operator-prometheus                 ClusterIP      172.16.149.221   <none>            9090/TCP                                
monitoring    ack-prometheus-operator-prometheus-node-exporter   ClusterIP      172.16.223.215   <none>            9100/TCP                                   
monitoring    alertmanager-operated                              ClusterIP      None             <none>            9093/TCP,9094/TCP,9094/UDP                                 
monitoring    prometheus-operated                                ClusterIP      None             <none>            9090/TCP                                    
nacos         nacos-headless                                     ClusterIP      None             <none>            8848/TCP,9848/TCP,9849/TCP,7848/TCP                      
nacos         nacos-svc                                          NodePort       172.16.100.9     <none>            8848:30848/TCP,9848:32764/TCP,9849:31229/TCP,7848:30285/TCP  
seata         seata-server                                       NodePort       172.16.166.219   <none>            8091:31558/TCP                                  
arms-pilot    arms-pilot-ack-arms-pilot                          ClusterIP      172.16.151.146   <none>            443/TCP                               
arms-prom     arms-prom-admin                                    ClusterIP      172.16.255.28    <none>            9335/TCP                            
arms-prom     arms-prom-server                                   ClusterIP      172.16.97.75     <none>            9090/TCP                                  
arms-prom     kube-state-metrics                                 ClusterIP      172.16.203.100   <none>            8080/TCP,8081/TCP                              
arms-prom     node-exporter                                      ClusterIP      None             <none>            9100/TCP                                
arms-prom     node-gpu-exporter                                  ClusterIP      172.16.228.90    <none>            9445/TCP                               
```


# MYSQL
```
quant-team2: rm-gs5bq7l2xk4lab5b9 
quant : rm-gs5au6566r2a679f1 (db:order_sync)
deliver : rm-gs55hnh58yhq8d89f (db:deliver)
hotcoin_order : rm-gs590g0iy6887a04v ()
apollo-notice : rm-gs548u5pd3d2354h8 (db:apolloportaldb ,apolloconfigdb)
hotcoin_agent : rm-gs5s4a0a28oa1zdky (db:hotcoin_agent,finance_asset,nacos,new_agent,casbinbeego)
contract : rm-gs5ke4q4a7od81azq (db:asset,boss,extra,integration,market,perpetual,scheduler_admin,user,wallet,wallet_snapshot)
hotcoin-master : rm-gs52k417554j4s862  (db:hotcoin)
cc-gs5cii3f218679l6y（clickhouse）(db:hotcoin_his)
hotcoin_order (PolarDB MySQL版)(db:hotcoin_order)
hotcoin (PolarDB MySQL版) (db:hotcoin)

```

# Redis
```
contract-newkline : r-gs543czjb2fopwo04o  -->r-gs543czjb2fopwo04o.redis.singapore.rds.aliyuncs.com
风控-fa-product: r-gs5c50lsla2rmrrnrc. -->r-gs5c50lsla2rmrrnrc.redis.singapore.rds.aliyuncs.com
bigdata_hy_matching : r-gs5i0riuxwkj8zwq5g. -->r-gs5i0riuxwkj8zwq5g.redis.singapore.rds.aliyuncs.com
hotcoin_limit : r-gs5wyfojtxyjfoiunr. -->r-gs5wyfojtxyjfoiunr.redis.singapore.rds.aliyuncs.com
hotcoin_redis : r-gs55i0sx3butr77yl9. -->r-gs55i0sx3butr77yl9.redis.singapore.rds.aliyuncs.com

```

# Mongodb
```
副本集实例列表:
(1) kline_history-match_event  
mongodb://root:****@dds-gs518cb4cc095a441.mongodb.singapore.rds.aliyuncs.com:3717
dds-gs518cb4cc095a442.mongodb.singapore.rds.aliyuncs.com:3717/admin?replicaSet=mgset-304617766

分片集群实例列表:
(2) saga_share  
mongodb://root:****@s-gs5bda1446195c44.mongodb.singapore.rds.aliyuncs.com:3717
s-gs5c4f9458c69624.mongodb.singapore.rds.aliyuncs.com:3717
s-gs5ea57eb0d05c74.mongodb.singapore.rds.aliyuncs.com:3717/admin

(3) kefu  
mongodb://root:****@s-gs528339c0ab7684.mongodb.singapore.rds.aliyuncs.com:3717
s-gs5b36b1c41bbbb4.mongodb.singapore.rds.aliyuncs.com:3717/admin
```

# 其他服务


| 服务 | 域名 | 最终指向 |
| ------ | ------ |------ |
|     apollo（配置）   |  http://47.241.91.34:31893/        | spot-match nodeport      |
|   Nacos     |   http://47.241.91.34:8848/nacos     |   spot-match nodeport    |
|   spot-kafka    |  http://47.241.91.34:9000      |  192.168.0.168:9999-->192.168.0.168:8080   |
|   contract-kafka    |       | (192.168.0.117:9092,192.168.0.118:9092,1192.168.0.119:9092) |
|   RocketMQ     |  http://47.241.91.34:18080    |   192.168.0.168:9999-->192.168.0.168:8080  |
|   RabbitMQ   |   http://47.241.91.34:5672     |   (192.168.0.104:5672｜192.168.0.195:5672｜192.168.0.241:5672)  |
|   任务调度     |   http://47.241.91.34:30702/toLogin    |   contract cluster nodeport   |
|   数据同步datax     |   http://47.241.91.34:30010   |   spot-match nodeport   |
|   邮件服务    |  https://www.engagelab.com/ 和 阿里云邮件推送    |    |
|   短信服务    |  美联短信    |    |




# 运维相关

| 服务 | 域名 | 最终指向 |
| ------ | ------ |------ |
| Gitlab| http://10.0.0.88/ |------ |
| Jenkins（cicd） | http://47.241.91.34:9090/ | 192.168.125.80:9090 |
| Jumpserver(跳板机) |https://new-jms.jmk666.top:8888/|192.168.125.86:80|
|   grafana   |  http://grafana.hotcx.com    |   8.214.35.175(lb) k8s svc -->ack-prometheus-operator-grafana   |
| 内部邮件服务   | http://mail-admin.hgmail.top   |     |
| 日志服务   |  阿里SLS日志服务   |     |
| v2ray   |  120.77.169.61   |  120.77.169.61   |



# 域名相关

| 域名 | 子域名 | 域名作用-路径 |
| ------ | ------ |------ |
| hotcoin.com | www.hotcoin.com |主站域名->www.hotcoin.com.v5dun.com->waf->8.214.35.175->[访问控制](https://slb.console.aliyun.com/slb/ap-southeast-1/acls/acl-gs5yhosmb3ow1l7kphwb1) |
| hotcoin.com | m.hotcoin.com |主站域名->m.hotcoin.com.v5dun.com->waf->8.222.211.41->[访问控制](https://slb.console.aliyun.com/slb/ap-southeast-1/acls/acl-gs5myjld8405gfxewtyjn) |
| hotcoin.com | mailer01.hotcoin.com |阿里-发邮件地址|
| hotcoin.com | mail03.hotcoin.com |阿里-发邮件地址|
| hotcoin.com | mail.hotcoin.com|阿里-发邮件地址|
| hotcoin.zone | hotcoin.zone |备用域名www.hotcoin.life->cloudflare->alb alb-5urzqym162y7oc751x.ap-southeast-1.alb.aliyuncs.com->无访问控制|
| hotcoin.link | hotcoin.link |备用域名www.hotcoin.life->cloudflare->alb alb-5urzqym162y7oc751x.ap-southeast-1.alb.aliyuncs.com->无访问控制 |
| hotcoin.life | www.hotcoin.life  |备用域名www.hotcoin.life->cloudflare->alb alb-5urzqym162y7oc751x.ap-southeast-1.alb.aliyuncs.com->无访问控制 |
| hotcoin.cc | www.hotcoin.cc |备用域名->cloudflare-waf->alb alb-5urzqym162y7oc751x.ap-southeast-1.alb.aliyuncs.com->无访问控制 |
| hotcoin666.top | hotcoin666.top |线路 |
| hotcoinnice.top | hotcoinnice.top |线路 |
| hotcoinwb.top | hotcoinwb.top |线路 |
| hotcoingex.top | hotcoingex.top |线路 |
| htcoinweb.top | htcoinweb.top |线路 |
| hotcoinotify.email | hotcoinotify.email |engagelab-邮件服务 |
| hotcoinevent.email | hotcoinevent.email |engagelab-邮件服务 |
| partagt.com | partagt.com |代理商后台 |
| hotcoin.email | hotcoin.email |阿里-发邮件地址|
| notification-hc.com | notification-hc.com |阿里-发邮件地址|
| hotcointechnology.com | hotcointechnology.com |测试域名 |
| pingduoduo.world | pingduoduo.world |aws app线路 |
| htcyc.top | htcyc.top |------ |
| hcinterface.top | hcinterface.top |------ |
| chbxj.xyz | chbxj.xyz |------ |
| hxobw.net | hxobw.net |------ |
| htemm.cc | htemm.cc |------ |
| htcoinlab.top | htcoinlab.top |app线路 |
| hotcointech.com | hotcointech.com |------ |
| hotcoindeliver.com | hotcoindeliver.com |代理使用的一个推广页面 |
| adfkaldk.com | adfkaldk.com |不需要了 |
| smlqbz.xyz | smlqbz.xyz |app线路，已经下线，可访问 |
| smlqbz.top | smlqbz.top |app线路，已经下线，可访问 |
| ertkjer.com | ertkjer.com |不需要了 |
| hotcoin.live | hotcoin.live |------ |
| hotcoin.run | hotcoin.run |------ |
| hotcoin.bid | hotcoin.bid |------ |
| hotcoin.men | hotcoin.men |------ |
| hcjmssec.com | idx.hcjmssec.com |singapore-liquidity-jumpserver已经停机 |
| fjcwd.com | fjcwd.com |------ |
| hcxzzy.com | hcxzzy.com |------ |
| hcxzapp.com | hcxzapp.com |------ |
| pdwxz.com | pdwxz.com |------ |
| ulmsg.com | ulmsg.com |logon使用，待确认|
| cstmsy.com | cstmsy.com |可能客服 |
| bdtuiwuyou.com | bdtuiwuyou.com |不使用了 |
| dskgn.com | dskgn.com |------ |
| cfget.com | cfget.com |------ |
| hgagt.com | hgagt.com |代理域名 |
| dlpck.com | dlpck.com |简版域名，已经取消 |
| qxqx8.cn | qxqx8.cn |不使用了|
| ndinp.com | ndinp.com |------ |
| hotcoinex.fit | hotcoinex.fit |------ |
| fcppp.com | fcppp.com |阿里ga线路 |
| bmkinp.com | bmkinp.com |------ |
| hc-notification.com | hc-notification.com |------ |
| ksapsap.com | ksapsap.com |------ |
| hotcoinex.email | hotcoinex.email |------ |
| fsrunlin.com | fsrunlin.com |------ |
| rbappxz.com | rbappxz.com |------ |
| hcappxz.com | hcappxz.com |------ |
| rbxzwz.com | rbxzwz.com |------ |
| hotcoinhk.cc | hotcoinhk.cc |------ |
| hotcoinhk.pro | hotcoinhk.pro |------ |
| hotcoinhk.top | hotcoinhk.top |------ |
| hotcoinhk.com | hotcoinhk.com |------ |
| bzkhgl.com | bzkhgl.com |------ |
| flentr.com | flentr.com |------ |
| woomsk.com | woomsk.com |------ |
| spentr.com | spentr.com |web线路 |
| thspeed.top | thspeed.top |------ |
| hotcoin.kim | hotcoin.kim |------ |
| hotcoin.so | hotcoin.so |------ |
| hotcoin.red | hotcoin.red |------ |
| hotcoinex.ltd | hotcoinex.ltd |------ |
| zzdks.com | zzdks.com |------ |
| flash666.top | flash666.top |------ |
| hotcoinlink.com | hotcoinlink.com |------ |
| linkhotcoin.com | linkhotcoin.com |------ |
| hotcflash.com | hotcflash.com |------ |
| customerhc.com | customerhc.com |客服线路|
| hotcoinex.tel | hotcoinex.tel |------ |
| hotcoin.fyi | hotcoin.fyi |------ |
| hotcoin.mom | hotcoin.mom |------ |
| hotcoin.lol | hotcoin.lol |------ |
| hotcoin.tel | hotcoin.tel |------ |
| hotcoinall.pro | hotcoinall.pro |------ |
| hotcoinall.info | hotcoinall.info |------ |
| hotcoinall.com | hotcoinall.com |------ |
| hotrebi.com | hotrebi.com |------ |
| hotcoffee.cc | hotcoffee.cc |------ |
| hotcoin.ltd | hotcoin.ltd |------ |
| hotcoin.fit | hotcoin.fit |------ |
| hotcoinex.plus | hotcoinex.plus |------ |
| hotcoinex.club | hotcoinex.club |------ |
| hotcoinex.life | hotcoinex.life |------ |
| hgmail.top | hgmail.top |内部邮件服务 |
| hotcx.com | web-registry.hotcx.com |web-registry.hotcx.com->47.238.90.253(web-gitlab-runner)[安全组](https://ecs.console.aliyun.com/securityGroupDetail/region/cn-hongkong/groupId/sg-j6cilygspot9uls7rsgg/detail/intranetIngress);|
|hotcx.com|test-agent-admin.hotcx.com|test-agent-admin.hotcx.com->clb 172.16.93.4(开发)->无访问控制 |
| aushotcoin.top | aushotcoin.top |------ |
| aushotcoin.com | aushotcoin.com |------ |
| jmk666.top | jmk666.top |------ |
| hotcoinfin.com | hotcoinfin.com |------ |
| appload1.top | appload1.top |------ |
| yzcencv.com | new-admin.yzcencv.com|管理台域名->mcgtauwf6has9f88abhzqhbjpddqqvqt.aliyunwaf5.com(开发环境看访问权限)->8.219.81.173->[访问控制](https://slb.console.aliyun.com/slb/ap-southeast-1/acls/acl-gs5rcdaa36ddlj6297eon) |
| yzcencv.com | newadmin.yzcencv.com|管理台域名->wlvrvvvfgnxfrn2nblpn8gcjfdonwpsv.aliyunwaf1.com(开发环境看访问权限)->8.219.81.173->[访问控制](https://slb.console.aliyun.com/slb/ap-southeast-1/acls/acl-gs5rcdaa36ddlj6297eon) |
| hotcoinex.pro | hotcoinex.pro |------ |




# 云上产品
```
产品明细
容器镜像服务企业版
ARMS Prometheus 监控服务 - 按量付费
ARMS 应用监控按量付费 - 按写入可观测数据量计费
ApsaraDB for KVStore (Subscription)
Cloud Disk（Pay-As-You-Go）
DAS专业版
DAS经济版
EIP
NAT网关（按量付费）
PolarDB 备份
VPN网关
Web应用防火墙 3.0（按量付费）
dm_intl
业务实时监控服务
云企业网带宽包（预付费）
云安全中心
云数据传输-跨地域
云数据传输-公网
全球加速

云数据库 PolarDB-按量付费
云数据库ClickHouse社区兼容版包年包月
云数据库MongoDB版分片集群 (包年包月)
云数据库MongoDB版副本集 (包年包月)
云数据库PolarDB-包年包月
云服务器ECS 按量付费
云服务器（包年包月）
云解析DNS（包年包月）
云防火墙
传统型负载均衡 (按量付费) 国际站
全局流量管理
共享带宽(按量付费)
关系型数据库（RDS）
国际PolarDB-X1.0计算包月
容器服务ACK国际站
应用型负载均衡(按量付费)国际站
应用监控 - 专家版 (按量付费)
应用监控资源包
开放存储服务（OSS）
对象存储 OSS 国际站资源包
快照
数据库备份DBS（按量付费）
数据管理-新版（按量付费）
日志服务+日志服务预付计划
服务计划
转发路由器
通用流量包（国际站）
.com域名（新加坡）
云盘性能_副本
数据管理-新版（包年包月
网络分析与监控
.live域名（国际站）
.men域名
.run域名（国际站）
.zone域名（国际站）
Alibaba Cloud CDN
DataWorks版本（包年包月）
bid域名（新加坡）
cc域名（新加坡）
pro域名（国际站）
数字证书管理服务（国际站）
数据传输服务（按量付费）
.top域名（新加坡）
.xyz域名（新加坡）
DataWorks Exclusive Resource
fully-managed flink
数据传输服务DTS(包年包月)
邮件推送资源包
.club域名（新加坡）
.email域名（国际站）
.fit域名（新加坡）
.life域名（国际站）
.link域名（国际站）
.ltd域名（新加坡）
.plus域名（国际站）
info域名（国际站）
.world域名（国际站）
.net域名（新加坡）
云电脑公网精品带宽国际站后付费
全球加速_基础带宽包（包年包月）
全球加速_实例规格（包年包月）
数据库自治服务DAS（按量付费）
无影云电脑国际站后付费
无影云电脑按月付费时长包（国际站）
跨域加速带宽包（包年包月）
EMAS-移动测试远程测试资源包
函数计算
.fyi域名（国际站）
.lol域名（国际站）
.mom域名（国际站）
.so 域名（国际站）
.tel域名（国际站）
ApsaraDB for KVStore(Redis)
GA资源包（国际站）
WAF3.0 SeCU资源包
kim域名（新加坡）
red域名（国际站）
公共DNS
```