### 生产定时任务

```
#matchsync队列堆积监控    # 每分钟执行一次 
#备注：获取队列堆积的数据并将其推送到 Prometheus 推送网关，以便监控队列堆积的状态 ，目前应该无效
*/1 * * * * python3 /data/scripts/monitor/matchsync_monitoring.py

# 数据统计 # 每天的 00:01 执行一次
#备注：此脚本每日自动运行，统计用户和合约数据，并将结果发送到指定的邮箱，用于系统运营的日常监控。
1 0 * * * python3 /data/scripts/monitor/counts.py >> /data/scripts/monitor/notice_mail.log 2>&1

# 异常事务超过10分钟 # 每 6 分钟执行一次 
#备注：该脚本监控 MongoDB 数据库中未完成的事务，检测它们的持续时间并在超过10分钟时发送报警信息。
*/6 * * * * python3 /data/scripts/monitor/mongo_transaction.py

#saga事务数量监控 # 每 5 分钟执行一次 
#备注：这个脚本用于检查 MongoDB 数据库中 saga 系统的事务数量是否超过指定的阈值（4,500,000）。一旦数量超过该阈值，脚本将发送报警信息
*/5 * * * * python3 /data/scripts/monitor/saga_alert.py

#实时在线用户查询 # 每分钟执行一次 
#备注：此脚本的作用是定期从 Redis 中提取在线用户数，并将该数据发送到监控系统，使得系统可以实时监控用户在线情况。
*/1 * * * * /usr/bin/python3 /data/scripts/monitor/online_user.py

#shibking空投快照 # 每周六的 18:00 执行一次 
#备注：这个 shibking_airdrop.sh 脚本的作用是执行一次 SQL 查询，将符合条件的用户钱包信息插入到数据库表 user_coin_wallet_snapshot 中
0 18 * * 6 bash /data/scripts/monitor/shibking_airdrop.sh

#钱包地址余量监控 # 每 2 小时的第 1 分钟执行一次
#备注：这个 wallet_addr.py 脚本用于监控主流币和山寨币钱包地址数量是否低于指定阈值，并在满足条件时发送警报通知，如果低于阈值，会生成类似 "比特币 地址只剩 200" 的通知信息并发送到 Teams 和钉钉。
1 */2 * * * /usr/bin/python3  /data/scripts/monitor/wallet_addr.py

# UserCoinWallet等同步，统计所有账户的总资产
# 每天的 23:55 执行一次 备注：该脚本通常作为定时任务定期执行，以确保历史数据表的同步和清理，同时通过报警功能监控同步进度和表状态，确保数据表同步成功,发到teams
55 23 * * * python3 /data/scripts/pymysql-table-sync/run.py >> /data/scripts/pymysql-table-sync/log.log 2>&1 

# 每小时的第 1 分钟执行一次   备注：小时数据同步：每小时从指定实例的表同步数据至历史库。 过期表清理：删除超过 8 小时的历史表。
1 */1 * * * python3 /data/scripts/pymysql-table-sync/run_hour.py >> /data/scripts/pymysql-table-sync/loghour.log 2>&1 

# 每天的 00:01 执行一次 #执行 create_tables 创建未来 9 天的表。执行 drop_old_tables 删除 7 到 10 天前的表。 用于确保数据库中有可用表以便进行用户资产分析，同时自动清理过期表。
1 0 * * * python3 /data/scripts/pymysql-table-sync/user_asset_analysis_cj.py >> /var/log/user_asset_analysis_sync.log 2>&1 


#上币监控  每 30 分钟执行一次 
#备注：这个脚本在有新的币种添加到系统时，每 30 分钟会发送一次提醒发到teams。
*/30 * * * * /usr/bin/python3 /data/scripts/monitor/new_up_coin.py

# 每分钟执行一次 #脚本用于监控 MySQL 数据库中的 f_entrust 表的行数，如果表行数超过指定阈值（200,000行），则向 Microsoft Teams 发送警报通知
*/1 * * * * bash /data/scripts/monitor/mysql_table_monitor.sh 

# mongo deal_fail_event 监控 # 每分钟执行一次 
#备注：一旦 deal_fail_event 集合中的文档数量达到或超过 2000，Microsoft Teams 将收到一条警告消息，提醒文档积压情况。
*/1 * * * * /usr/bin/python3 /data/scripts/monitor/mongo_deal_fail_event.py > /dev/null

# 合约每日资产统计 # 每天的 00:01 执行一次 
#备注：生成合约每日资产统计信息并发送到 Telegram 群组
1 0 * * * /usr/bin/python3 /data/scripts/assets_stats_cj.py > /dev/null

# 异常日志到达阀值告警 # 每分钟执行一次
#备注：主要用于检测 MongoDB 数据库中的异常日志条目，并在达到一定次数的阈值时向 Microsoft Teams 发送警报消息
*/1 * * * * python3 /data/scripts/service-exlog-alarm/run.py > /dev/null


# 删除datax log日志，只保留三天 # 每天的 01:00 执行一次 
备注：用于删除 MySQL 数据库中 datax_admin 库 job_log 表中超过 3 天的日志记录
0 1 * * * /usr/bin/python3 /data/scripts/del_datax_log.py >> /data/scripts/datax_delete_log.log 2>&1

# tg 报警datax_同步异常  # 每 15 分钟执行一次
备注：通过检查数据库中 DataX 的日志，监控是否有最近 15 分钟内发生的同步异常。如果存在异常，则发送告警消息到 Telegram，表明同步出错；一旦恢复正常，也会发送消息通知
*/15 * * * * /usr/bin/python3 /data/scripts/datax_error_alarm.py >> /data/scripts/datax_error_alarm.log 2>&1

#清理new_xxl_job log # 每天的 04:00 执行一次 
#备注：连接到 MySQL 数据库 new_xxl_job，然后执行 SQL 删除操作以清除表 xxl_job_log 中指定时间之前的日志记录
0 4 * * * /data/scripts/new_xxl_job_deletelog_b_7ds.py > /dev/null


# 每 30 分钟执行一次 #清理 MongoDB 中不需要的旧事务数据和状态，保持数据库简洁，提高查询效率
*/30 * * * * /bin/bash /data/scripts/delete_normal_trans.sh

#mongodb moniter # 每月 1 日的凌晨 0 点执行一次
#脚本主要用于持续监控 MongoDB 中 deal_fail_event_2024_11 集合的记录数量变化，若有新记录插入则会发送通知至 Microsoft Teams 和钉钉
0 0 1 * * bash /data/scripts/crontab.sh

liquidate监控
systemctl status liquidate_monitor
使用了
/data/scripts/liquidate_monitor/liqui_mon.py
```




### 测试环境定时任务
```
#每隔一天的凌晨 2:01 #清理所有未被使用的 Docker 镜像。
1 2 */1 * * docker image prune -a -f

#每隔一天的凌晨 2:01  #删除所有悬空的 Docker 镜像（无标签的镜像）。
1 2 */1 * * docker rmi -f $(docker images --filter "dangling=true" -q --no-trunc)


# UserCoinWallet等同步，统计所有账户的总资产 #每天晚上 23:55执行
55 23 * * * /usr/bin/python3.11 /data/scripts/pymysql-table-sync/run.py >> /data/scripts/pymysql-table-sync/log.log 2>&1

#每小时的第 1 分钟执行
1 */1 * * * /usr/bin/python3.11 /data/scripts/pymysql-table-sync/run_hour.py >> /data/scripts/pymysql-table-sync/log_hour.log 2>&1

#每天凌晨 0:01执行
#1 0 * * * /usr/bin/python3.11 /data/scripts/pymysql-table-sync/user_asset_analysis.py > /dev/null

#每天凌晨 0:01执行
1 0 * * * python3 /data/scripts/pymysql-table-sync/user_asset_analysis_cj.py >> /var/log/user_asset_analysis_sync.log 2>&1

#每 3 小时的第 1 分钟
1 */3 * * * python3 /data/scripts/k8s-pyclient/delete_helm_secrets.py >> /data/scripts/k8s-pyclient/log.log 2>&1

#每天凌晨 0:01执行
1 0 * * * rm -f /apps/rdr/*.rdb && systemctl restart rdr

#1 0 * * * /usr/local/bin/helm  --kubeconfig=/root/.kube/spot -n infra uninstall fluentd-err-filter
#55 7 * * * cd /opt/yaml/log-cluster/standalone/fluentd && /usr/local/bin/helm --kubeconfig=/root/.kube/spot -n infra upgrade --install fluentd-err-filter -f filter-log-mongo.yaml .

#每小时的第 1 分钟执行 
1 */1 * * * /usr/local/bin/kubectl --context edas -n new-cluster rollout restart deploy service-mag-margin

#每天凌晨 2:01 执行更新 GeoIP 数据，并将日志输出到文件
1 2 * * * python3 /apps/geoip/getgeoip.py > /apps/geoip/log.txt

# ssl证书过期检查 每天上午 10:01
1 10 * * * bash /apps/check-cert/cjj/ssl_team.sh >> /apps/check-cert/cjj/log.txt 2>&1

# 测试大表truncate #每天凌晨 4:01执行
1 4 * * * python3 /apps/mysql-truncate-job/run.py > /dev/null 2>&1

# 清理rocketmq日志 #每小时的第 20 分钟 删除 RocketMQ 控制台日志文件。
20 */1 * * * rm -f /var/lib/docker/overlay2/*/merged/root/logs/consolelogs/rocketmq-console-2*.log
```





### 生产被注释掉的定时任务
```
#mongo事务删除
#0 */1 * * * mongo s-gs54007b250ced84.mongodb.singapore.rds.aliyuncs.com:3717/saga -u "saga" -p "grKbxLCRmq3bpuD8" /opt/saga.js
#0 */1 * * * mongo s-gs5bda1446195c44.mongodb.singapore.rds.aliyuncs.com:3717/saga -u "saga001" -p "mZRX+0ylo6JHI5bw" /opt/saga.js

# rabbitmq_message_ready
#*/15 * * * * /usr/bin/python3 /data/scripts/monitor/message_ready.py "192.168.121.219" "hotcoin" "92cb92580b0f"

#f_entrust历史委单任务迁移监控
#*/5 * * * * bash /data/scripts/f_entrust_minitoring.sh


#删除MongoDB 历史数据
#1 1 1 * * python3 /data/scripts/del_mongo.py



#统计据推送到promethues
#0 * * * * python3 /data/scripts/monitor/push_prom.py

# accserver mq 监控
#*/5 * * * * /usr/bin/python3 /data/scripts/monitor/accmq.py

#多放币与广告超卖监控
#*/5 * * * * /usr/bin/python3 /data/scripts/monitor/otc.py

#证书监控
#30 10 * * * bash /data/scripts/ssl_check.sh
#1 10,17 * * * python3 /data/scripts/check-cert/check_cert.py >> /data/scripts/check-cert/log.txt 2>&1


#删除合约无效订单表
#*/1 * * * * /usr/bin/python3  /data/scripts/del_user_bill.py
#*/1 * * * * /usr/bin/python3  /data/scripts/del_order_finish_link_usdt_202108.py
#*/1 * * * * /usr/bin/python3  /data/scripts/del_order_finish_xrp_usdt_202108.py

#*/1 * * * * /usr/bin/python3  /data/scripts/del_user_bill_202204.py
#*/1 * * * * /usr/bin/python3  /data/scripts/del_user_bill_202103.py


#钱包NFT空投快照
#0 20 10 * * bash /data/scripts/monitor/wallet_snapshot.sh


#合约历史订单消费监控
#*/2 * * * * /usr/bin/python3 /data/scripts/monitor/contract_matching.py

#30 1 * * * bash /data/scripts/del_market_log.sh

#*/1 * * * * bash /data/scripts/monitor/match_process.sh



#*/1 * * * * /usr/bin/python3 /data/scripts/del_fentrust.py


#05 00  * * * python3 /data/scripts/ucw/count_user.py


#*/1 * * * * python3 /data/scripts/service-exlog-alarm/dx.py > /dev/null


#delete f_user_profitloss_analysis befroe 20220901
#*/1 * * * * python3 /data/scripts/delete_f_user_profitloss_analysis.py

#*/1 * * * *  /usr/bin/python3 /data/scripts/delete_mkt_log_monit.py
#*/1 * * * *  /usr/bin/python3 /data/scripts/delete_mkt_contract_trade_stat.py


#liquidate监控
#systemctl status liquidate_monitor
#/data/scripts/liquidate_monitor/run.py

#UserCoinWallet备份,预防同步失败以便手动导入
#59 23 * * * /bin/bash /data/scripts/user_coin_wallet_backup.sh


```

