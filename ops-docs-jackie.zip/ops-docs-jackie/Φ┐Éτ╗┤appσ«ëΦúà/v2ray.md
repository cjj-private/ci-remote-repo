
### 测试环境上翻墙服务器汇总
```
v2ray :

*****
深圳-主机v2ray-client
10.0.0.225:10909 内网使用naive代理 
120.77.169.61:24831（外网,v2ray 外网 nginx-->v2ray-2024）

*****
香港--主机v2ray-2024
172.18.51.54
Systemctl status v2ray

*****
香港--主机：Kefu-v2ray-01
172.31.83.73 
域名:wk.thspeed.top:13569
Systemctl status v2ray
/usr/bin/caddy run --environ --config /etc/caddy/caddy_server.json 

******
香港--主机：jishu-v2ray
172.31.83.74
域名:ms.jmk666.top:9681
Systemctl status v2ray 


香港-主机：kefu-v2ray-02
172.31.130.238 内网
/usr/local/v2ray/v2ray -config /usr/local/v2ray/config.json有个boss 


devops阿里云账号
香港主机：客服运营专用v2ray 
172.30.124.250(内网) 
8.217.202.22（外网）
http://f2d.fjcwd.com:31658/


```

### 开发环境v2ray. 8.216.130.179(外网地址)  
```
开发环境账号
新加坡主机-8.216.130.179
域名：asdf.zzdks.com:31336


```

### naive服务器跑10.0.0.225:10909
#### 1,Naive 检查健康服务：/apps/naive-health/naive_ctrl.py
[root@v2ray-client naive-health]# cat naive_check.py
```
import logging
import random
from datetime import datetime, timedelta

import requests
from apscheduler.schedulers.blocking import BlockingScheduler


logging.basicConfig(level=logging.INFO)
sched = BlockingScheduler()
metrics = {}  # 分钟metrics
s5 = {'http': 'socks5://127.0.0.1:10909', 'https': 'socks5://127.0.0.1:10909'}
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', }


def fetch(url):
    try:
        with requests.head(url, timeout=4, proxies=s5, headers=headers) as r:
            logging.info(f' {url} {r.status_code}')
    except Exception as ex:
        logging.info(ex)
        return True


@sched.scheduled_job('interval', seconds=5)
def tick():
    now = datetime.now()
    fmt = '%Y%m%d%H%M'
    curr_minute = int(now.strftime(fmt))
    prev_minute = int((now - timedelta(minutes=1)).strftime(fmt))
    urls = ['https://x.com/?lang=en', 'https://t.me/', ]
    if fetch(random.choice(urls)):
        metrics.setdefault(curr_minute, []).append(True)
    logging.info(metrics)

    curr_list = metrics.get(curr_minute)
    if curr_list and len(curr_list) >= 3:
        metrics.pop(curr_minute)
        with requests.get('http://8.212.49.219:8003/not-health') as r:
            logging.info(r.text)
    # 清除2分钟前的数据，避免字典无限扩大
    for minute in list(metrics):
        if minute < prev_minute:
            metrics.pop(minute)


sched.start()

```


####  2,navie服务：/root/naiveproxy-v108.0.5359.94-1-linux-x64/naive


####  caddy和naive-ctrl服务  172.31.83.75(内网)  8.212.49.219（外网）

**************
[root@navieproxy naive-health]# cat /etc/systemd/system/naive.service
```
[Unit]
Description=Caddy
Documentation=https://caddyserver.com/docs/
After=network.target network-online.target
Requires=network-online.target

[Service]
Type=notify
User=root
Group=root
ExecStart=/usr/local/bin/caddy run --environ --config /etc/caddy/caddy_server.json
ExecReload=/usr/local/bin/caddy reload --config /etc/caddy/caddy_server.json
TimeoutStopSec=5s
LimitNOFILE=1048576
LimitNPROC=512
PrivateTmp=true
ProtectSystem=full
AmbientCapabilities=CAP_NET_BIND_SERVICE

[Install]
WantedBy=multi-user.target
[root@navieproxy naive-health]# cat /etc/systemd/system/naive-ctrl.service 
[Unit]
Description=naive ctrl 如不能国内不能翻，重启naive服务
After=multi-user.target

[Service]
#Type=simple
WorkingDirectory=/apps/naive-health
Restart=always
ExecStart=/usr/local/bin/gunicorn naive_ctrl:app -b :8003 --access-logfile -

[Install]
WantedBy=multi-user.target

**********************


```