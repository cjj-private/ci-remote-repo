### 安装步骤
#### 1，安装docker
#### 2，anyconnect(docker-compose.yaml,server.toml,conf/profile.xml和上面一样)
```
root@iZj6cax32u9dr7c88eewi4Z:/apps/anyconnect# cat docker-compose.yaml
version: '3'

services:
  anyconnect:
    image: bjdgyc/anylink:0.8.1
    restart: always
    container_name: anyconnect
    privileged: true
    command: -c=/etc/server.toml
    ports:
    - "28088:8800"
    - "22826:443"
    environment:
    - IPV4_CIDR=10.15.0.0/16
    volumes:
    - ./server.toml:/etc/server.toml
    - ./conf:/app/conf

networks:
  default:
    external:
      name: mysql_default



root@iZj6cax32u9dr7c88eewi4Z:/apps/anyconnect# cat server.toml
version: '3'

services:
  anyconnect:
    image: bjdgyc/anylink:0.8.1
    restart: always
    container_name: anyconnect
    privileged: true
    command: -c=/etc/server.toml
    ports:
    - "28088:8800"
    - "22826:443"
    environment:
    - IPV4_CIDR=10.15.0.0/16
    volumes:
    - ./server.toml:/etc/server.toml
    - ./conf:/app/conf

networks:
  default:
    external:
      name: mysql_default



root@iZj6cax32u9dr7c88eewi4Z:/apps/anyconnect# cat server.toml
#数据文件
db_type = "mysql"
#db_source = "./conf/anylink.db"
db_source = "anylink:lipu1111@tcp(mysql:3306)/anylink?charset=utf8"
#证书文件
cert_file = "./conf/vpn_cert.crt"
cert_key = "./conf/vpn_cert.key"
files_path = "./conf/files"
log_level = "debug"

#系统名称
issuer = "lp anylink"
#后台管理用户
admin_user = "admin"
admin_pass = "$2a$10$BgGkmPTrav9VIKOm5xmkL.w0ih4HSv4KIEQPoSkosm4qzbWsn3CZi"
jwt_secret = "BV3XnBmUMWsnGp4wVbSGXwWAEfGjzX_Nz_Xv9ua07dqHiU220KvnOCNNbYUdkC_3"

#服务监听地址
server_addr = ":443"
#后台服务监听地址
admin_addr = ":8800"


link_mode = "tun"
#客户端分配的ip地址池
ipv4_master = "eth0"
ipv4_cidr = "10.15.0.0/16"
ipv4_gateway = "10.15.0.1"
ipv4_start = "10.15.0.2"
ipv4_end = "10.15.255.254"

#最大客户端数量
max_client = 200
#单个用户同时在线数量
max_user_client = 5
#IP租期(秒)
ip_lease = 1209600

#默认选择的组
default_group = "dev"
```
#### 4,anyconect-->conf/profile.xml
```
root@iZj6cax32u9dr7c88eewi4Z:/apps/anyconnect/conf# cat profile.xml
<?xml version="1.0" encoding="UTF-8"?>
<AnyConnectProfile xmlns="http://schemas.xmlsoap.org/encoding/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                   xsi:schemaLocation="http://schemas.xmlsoap.org/encoding/ AnyConnectProfile.xsd">

    <ClientInitialization>
        <UseStartBeforeLogon UserControllable="false">false</UseStartBeforeLogon>
        <StrictCertificateTrust>false</StrictCertificateTrust>
        <RestrictPreferenceCaching>false</RestrictPreferenceCaching>
        <RestrictTunnelProtocols>IPSec</RestrictTunnelProtocols>
        <BypassDownloader>true</BypassDownloader>
        <WindowsVPNEstablishment>AllowRemoteUsers</WindowsVPNEstablishment>
        <LinuxVPNEstablishment>AllowRemoteUsers</LinuxVPNEstablishment>
        <CertEnrollmentPin>pinAllowed</CertEnrollmentPin>
        <CertificateMatch>
            <KeyUsage>
                <MatchKey>Digital_Signature</MatchKey>
            </KeyUsage>
            <ExtendedKeyUsage>
                <ExtendedMatchKey>ClientAuth</ExtendedMatchKey>
            </ExtendedKeyUsage>
        </CertificateMatch>

        <BackupServerList>
            <HostAddress>localhost</HostAddress>
        </BackupServerList>
    </ClientInitialization>

    <ServerList>
        <HostEntry>
            <HostName>VPN Server</HostName>
            <HostAddress>localhost</HostAddress>
        </HostEntry>
    </ServerList>
</AnyConnectProfile>
```

#### anyconnect-authtls(docker-compose.yaml,server.toml,conf/profile.xml和上面一样)
```
root@iZj6cax32u9dr7c88eewi4Z:/apps/anyconnect-authtls# cat docker-compose.yaml
version: '3'

services:
  anyconnect-auth:
    image: bjdgyc/anylink:0.8.1
    restart: always
    container_name: anyconnect-authtls
    privileged: true
    command: -c=/etc/server.toml
    ports:
    - "28089:8800"
    - "24618:443"
    environment:
    - IPV4_CIDR=10.17.0.0/16
    volumes:
    - ./server.toml:/etc/server.toml
    - ./conf:/app/conf

networks:
  default:
    external:
      name: mysql_default
```
```
root@iZj6cax32u9dr7c88eewi4Z:/apps/anyconnect-authtls# cat server.toml
#数据文件
db_type = "mysql"
#db_source = "./conf/anylink.db"
db_source = "anylink:lipu1111@tcp(mysql:3306)/anylink?charset=utf8"
#证书文件
cert_file = "./conf/vpn_cert.crt"
cert_key = "./conf/vpn_cert.key"
files_path = "./conf/files"
log_level = "debug"

#系统名称
issuer = "lp anylink"
#后台管理用户
admin_user = "admin"
admin_pass = "$2a$10$BgGkmPTrav9VIKOm5xmkL.w0ih4HSv4KIEQPoSkosm4qzbWsn3CZi"
jwt_secret = "BV3XnBmUMWsnGp4wVbSGXwWAEfGjzX_Nz_Xv9ua07dqHiU220KvnOCNNbYUdkC_3"

#服务监听地址
server_addr = ":443"
#后台服务监听地址
admin_addr = ":8800"


link_mode = "tun"
#客户端分配的ip地址池
ipv4_master = "eth0"
ipv4_cidr = "10.15.0.0/16"
ipv4_gateway = "10.15.0.1"
ipv4_start = "10.15.0.2"
ipv4_end = "10.15.255.254"

#最大客户端数量
max_client = 200
#单个用户同时在线数量
max_user_client = 5
#IP租期(秒)
ip_lease = 1209600

#默认选择的组
default_group = "dev"
```
#### mysql
```
root@iZj6cax32u9dr7c88eewi4Z:/apps/mysql# cat docker-compose.yaml
version: '3'

services:
  mysql:
    container_name: mysql
    image: mysql:5.7
    restart: always
    environment:
    - MYSQL_ROOT_PASSWORD=lipu1111
    - TZ=Asia/Shanghai
    command: --character-set-server=utf8mb4 --collation-server=utf8mb4_unicode_ci
    ports:
    - "3306:3306"
    volumes:
    - ./data:/var/lib/mysql
```

#### 启动docker compose up -d 
#### 停止docker compose down

