[参考anylink github](https://github.com/bjdgyc/anylink)

```
#准备好docker
git clone https://github.com/bjdgyc/anylink.git
# docker编译 参考软件版本(不需要安装)
# go 1.20.12
# node v16.20.2
# yarn 1.22.19


cd anylink

# 编译前端
bash build_web.sh
# 编译 anylink-deploy 发布文件
bash build.sh

# 注意使用root权限运行
cd anylink-deploy
sudo ./anylink

# 默认管理后台访问地址
# https://host:8800
# 默认账号 密码
# admin 123456

/usr/local/anylink-deploy/anylink --conf=/usr/local/anylink-deploy/conf/server.toml

```

#### server.toml
```
#示例配置信息,记得修改证书信息

#其他配置文件,可以使用绝对路径
#或者相对于 anylink 二进制文件的路径

#数据文件
db_type = "sqlite3"
db_source = "./conf/anylink.db"
#证书文件 使用跟nginx一样的证书即可
cert_file = "./conf/certificate.crt"
cert_key = "./conf/private.key"
files_path = "./conf/files"
profile = "./conf/profile.xml"
#日志目录,为空写入标准输出
log_path = "./log"
#log_path = "/usr/local/anylink/anylink-deploy/log"
log_level = "debug"
pprof = false

#系统名称
issuer = "管理台专用VPN"
#后台管理用户
admin_user = "admin"
admin_pass = "$2a$10$m.IT2ccaWOjIAWtvj3Eud.BNx2UIIN/VIgzJeRYA3K7UgOY5Af7ia"
jwt_secret = "qDXeLkPmO5NI1r01aBnDpxfQOksvit2rcTLJIjd1JF49FADGbcQmioV6deKVRdCZ_g7P1WM"


#服务监听地址
server_addr = ":30001"
#开启 DTLS, 默认关闭
server_dtls = false
server_dtls_addr = ":4433"
#后台服务监听地址
admin_addr = ":30002"
#开启tcp proxy protocol协议
proxy_protocol = false

link_mode = "tun"

#客户端分配的ip地址池
ipv4_master = "eth0"
ipv4_cidr = "172.31.201.0/16"
ipv4_gateway = "172.31.207.253"
ipv4_start = "172.31.201.100"
ipv4_end = "172.31.201.150"

#最大客户端数量
max_client = 200
#单个用户同时在线数量
max_user_client = 3
#IP租期(秒)
ip_lease = 1209600

#默认选择的组
default_group = "one"

#客户端失效检测时间(秒) dpd > keepalive
cstp_keepalive = 20
cstp_dpd = 30
mobile_keepalive = 40
mobile_dpd = 50

#设置最大传输单元
mtu = 1460

#session过期时间，用于断线重连，0永不过期
session_timeout = 3600
auth_timeout = 0
audit_interval = -1
```