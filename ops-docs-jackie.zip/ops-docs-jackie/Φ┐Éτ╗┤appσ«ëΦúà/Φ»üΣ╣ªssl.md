### 购买ip证书

```
在zerossl中购买证书，会让验证
http://120.77.169.61/.well-known/pki-validation/01285146D9ADF309218E519439C3D614.txt

在服务器120.77.169.61
nginx服务 80中通常/usr/local/html下创建.well-known/pki-validation/01285146D9ADF309218E519439C3D614.txt添加zerossl需要的内容

然后安全组打开80给0.0.0.0
zerossl验证成功后即可下载到ssl证书
然后将证书放入服务器中即可。
记得nginx -s reload 即可，然后验证
例如：https://120.77.169.61:24831/
```

