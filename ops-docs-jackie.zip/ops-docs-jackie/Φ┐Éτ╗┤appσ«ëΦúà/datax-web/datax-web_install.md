# datax-web安装步骤
##### 1，创建数据库
```
例如：
    DB_HOST=rm-gs5s4a0a28oa1zdky.mysql.singapore.rds.aliyuncs.com
    DB_PORT=3306
    DB_USERNAME=datax
    DB_PASSWORD=****
    DB_DATABASE=datax_admin

```
##### 2，拉取公共镜像eurekas/datax-admin和eurekas/datax-executor 
##### 3，docker tag 镜像为 hotcoin-registry-registry-vpc.ap-southeast-1.cr.aliyuncs.com/prod_contract/eurekas_datax-executor:1.0
##### 4，docker push hotcoin-registry-registry-vpc.ap-southeast-1.cr.aliyuncs.com/prod_contract/eurekas_datax-executor:1.0
##### 5，确保部署机器有拉和取得仓库的权限aliyun-regsecret
##### 6，将datax-web.sql导入到数据库中
##### 7，kubectl apply -f datax-web.yaml
##### 8，启动检查kubectl get pods |grep datax
##### 9，配置clb--->k8s中端口30010，控制访问权限公司ip
##### 10，前台登录 http://47.241.91.34:30010/index.html 