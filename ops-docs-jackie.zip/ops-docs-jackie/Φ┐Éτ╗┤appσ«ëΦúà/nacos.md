### 准备2个文件：
### 1，nacos-v210.yaml.   2,configmap
### svc中的下面要和新的一致。
```
selector:
  app: nacos-v210
```
```
[root@new-jenkins nacos-upgrade]# cat nacos-v210.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: nacos-v210
  namespace: nacos
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nacos-v210
  serviceName: nacos-hs-v210
  template:
    metadata:
      creationTimestamp: null
      labels:
        app: nacos-v210
    spec:
      affinity:
        podAntiAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
          - labelSelector:
              matchExpressions:
              - key: app
                operator: In
                values:
                - nacos-v210
            topologyKey: kubernetes.io/hostname
      containers:
      - env:
        - name: JVM_XMX
          value: "4g"
        - name: JVM_XMS
          value: "4g"
        - name: NACOS_REPLICAS
          value: "3"
        - name: SERVICE_NAME
          value: nacos-hs-v210
        - name: DOMAIN_NAME
          value: cluster.local
        - name: POD_NAMESPACE
          valueFrom:
            fieldRef:
              apiVersion: v1
              fieldPath: metadata.namespace
        - name: MYSQL_SERVICE_HOST
          valueFrom:
            configMapKeyRef:
              key: mysql.host
              name: nacos-cm-v210
        - name: MYSQL_SERVICE_DB_NAME
          valueFrom:
            configMapKeyRef:
              key: mysql.db.name
              name: nacos-cm-v210
        - name: MYSQL_SERVICE_PORT
          valueFrom:
            configMapKeyRef:
              key: mysql.port
              name: nacos-cm-v210
        - name: MYSQL_SERVICE_USER
          valueFrom:
            configMapKeyRef:
              key: mysql.user
              name: nacos-cm-v210
        - name: MYSQL_SERVICE_PASSWORD
          valueFrom:
            configMapKeyRef:
              key: mysql.password
              name: nacos-cm-v210
        - name: NACOS_SERVER_PORT
          value: "8848"
        - name: NACOS_APPLICATION_PORT
          value: "8848"
        - name: PREFER_HOST_MODE
          value: hostname
        image: hotcoin-registry-registry-vpc.ap-southeast-1.cr.aliyuncs.com/prod_contract/nacos-server:v2.1.0
        imagePullPolicy: IfNotPresent
        name: nacos-v210
        ports:
        - containerPort: 8848
          name: client-port
          protocol: TCP
        - containerPort: 9848
          name: client-rpc
          protocol: TCP
        - containerPort: 9849
          name: raft-rpc
          protocol: TCP
        - containerPort: 7848
          name: old-raft-rpc
          protocol: TCP
        resources:
          requests:
            cpu: 500m
            memory: 2Gi
        volumeMounts:
        - mountPath: /home/nacos/plugins/peer-finder
          name: data-v210
          subPath: peer-finder
        - mountPath: /home/nacos/data
          name: data-v210
          subPath: data
        - mountPath: /home/nacos/logs
          name: data-v210
          subPath: logs
      initContainers:
      - image: hotcoin-registry-registry-vpc.ap-southeast-1.cr.aliyuncs.com/prod_contract/nacos-peer-finder-plugin:1.1
        imagePullPolicy: IfNotPresent
        name: peer-finder-plugin-install
        volumeMounts:
        - mountPath: /home/nacos/plugins/peer-finder
          name: data-v210
          subPath: peer-finder
      restartPolicy: Always
      terminationGracePeriodSeconds: 30
      imagePullSecrets:
      - name: aliyun-regsecret
  updateStrategy:
    rollingUpdate:
      partition: 0
    type: RollingUpdate
  volumeClaimTemplates:
  - apiVersion: v1
    kind: PersistentVolumeClaim
    metadata:
      annotations:
        volume.beta.kubernetes.io/storage-class: alicloud-disk-essd
      name: data-v210
    spec:
      accessModes:
      - ReadWriteMany
      resources:
        requests:
          storage: 200Gi
      volumeMode: Filesystem


[root@new-jenkins nacos-upgrade]# kn get configmap nacos-cm-v210 -n nacos -o yaml
apiVersion: v1
data:
  mysql.db.name: nacos_v210
  mysql.host: rm-gs5s4a0a28oa1zdky.mysql.singapore.rds.aliyuncs.com
  mysql.password: I2l6jDGfEaTm1AHS
  mysql.port: "3306"
  mysql.user: nacos
kind: ConfigMap
metadata:
  annotations:
    kubectl.kubernetes.io/last-applied-configuration: |
      {"apiVersion":"v1","data":{"mysql.db.name":"nacos_v210","mysql.host":"rm-gs5s4a0a28oa1zdky.mysql.singapore.rds.aliyuncs.com","mysql.password":"I2l6jDGfEaTm1AHS","mysql.port":"3306","mysql.user":"nacos"},"kind":"ConfigMap","metadata":{"annotations":{},"name":"nacos-cm-v210","namespace":"nacos"}}
  creationTimestamp: "2024-09-18T19:56:39Z"
  managedFields:
  - apiVersion: v1
    fieldsType: FieldsV1
    fieldsV1:
      f:data:
        .: {}
        f:mysql.db.name: {}
        f:mysql.host: {}
        f:mysql.password: {}
        f:mysql.port: {}
        f:mysql.user: {}
      f:metadata:
        f:annotations:
          .: {}
          f:kubectl.kubernetes.io/last-applied-configuration: {}
    manager: kubectl-client-side-apply
    operation: Update
    time: "2024-09-18T19:56:39Z"
  name: nacos-cm-v210
  namespace: nacos
  resourceVersion: "491009448"
  uid: 85c23e70-0bcf-4fb4-ad7f-80d20458e47e

```