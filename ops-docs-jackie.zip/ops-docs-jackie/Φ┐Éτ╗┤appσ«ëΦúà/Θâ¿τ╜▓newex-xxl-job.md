### 测试环境部署新项目newex-xxl-job

```
1,首先将开发给的sql脚本执行在dms中
2，授权cotract用户有这个new-xxl-job 这个database的权限
GRANT ALL PRIVILEGES ON new_xxl_job.* TO 'contract'@'%';
FLUSH PRIVILEGES;
3，在jenkins中增加一个项目，复制来自于newex-scheduler
4,修改/data/scripts/yaml/newex-xxl-job/newex-xxl-job.yaml中的配置
5，修改jenkins中配置中的相关文件名字
6，部署。kubectl get svc |grep xxl
7，测试访问
http://172.18.43.200:30703/xxl-job-admin/
测试
http://172.16.97.123:30703/xxl-job-admin/
开发

admin/123456
```