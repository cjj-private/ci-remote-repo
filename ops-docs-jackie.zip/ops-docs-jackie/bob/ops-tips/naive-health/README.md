## naive代理(内部socks5代理)健康检查及重启
- 避免各组人员发现代理不可用了，再由运维手动重启，不去重启一般几分以上也会自动恢复
- 解决方法：国内使用sock5://10.0.0.225:10909每5秒对tg twitter发起请求，不可达3次以上，对naive server发起重启服务请求，最快15秒恢复

## 脚本说明
- naive_check.py  # 定时任务，部署在国内naive sock5客户端
- naive_ctrl.py  # 重启naive server http接口服务，部署在naive上

## systemd
- systemctl status/restart/stop naive-check  # sock5客户端
- systemctl status/restart/stop naive-ctrl  # naive server