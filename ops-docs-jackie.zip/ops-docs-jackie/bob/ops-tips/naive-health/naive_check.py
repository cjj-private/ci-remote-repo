import logging
import random
from datetime import datetime, timedelta

import requests
from apscheduler.schedulers.blocking import BlockingScheduler


logging.basicConfig(level=logging.INFO)
sched = BlockingScheduler()
metrics = {}  # 分钟metrics
s5 = {'http': 'socks5://127.0.0.1:10909', 'https': 'socks5://127.0.0.1:10909'}
headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36', }


def fetch(url):
    try:
        with requests.head(url, timeout=4, proxies=s5, headers=headers) as r:
            logging.info(f' {url} {r.status_code}')
    except Exception as ex:
        logging.info(ex)
        return True


@sched.scheduled_job('interval', seconds=5)
def tick():
    now = datetime.now()
    fmt = '%Y%m%d%H%M'
    curr_minute = int(now.strftime(fmt))
    prev_minute = int((now - timedelta(minutes=1)).strftime(fmt))
    urls = ['https://x.com/?lang=en', 'https://t.me/', ]
    if fetch(random.choice(urls)):
        metrics.setdefault(curr_minute, []).append(True)
    logging.info(metrics)

    curr_list = metrics.get(curr_minute)
    if curr_list and len(curr_list) >= 3:
        metrics.pop(curr_minute)
        with requests.get('http://naive-server:8003/not-health') as r:  # naive-server:8003开启安全组信任
            logging.info(r.text)
    # 清除2分钟前的数据，避免字典无限扩大
    for minute in list(metrics):
        if minute < prev_minute:
            metrics.pop(minute)


sched.start()