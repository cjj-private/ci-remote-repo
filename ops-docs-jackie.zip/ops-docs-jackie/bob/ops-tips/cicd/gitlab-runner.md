# gitlab-runner 安装

## centos7 添加源
`vim /etc/yum.repos.d/gitrunner.repo`
```
[runner_gitlab-runner]
name=runner_gitlab-runner
baseurl=https://packages.gitlab.com/runner/gitlab-runner/el/7/$basearch
repo_gpgcheck=1
gpgcheck=0
enabled=1
gpgkey=https://packages.gitlab.com/runner/gitlab-runner/gpgkey
       https://packages.gitlab.com/runner/gitlab-runner/gpgkey/runner-gitlab-runner-4C80FB51394521E9.pub.gpg
       https://packages.gitlab.com/runner/gitlab-runner/gpgkey/runner-gitlab-runner-49F16C5CC3A0F81F.pub.gpg
sslverify=1
sslcacert=/etc/pki/tls/certs/ca-bundle.crt
metadata_expire=300

[runner_gitlab-runner-source]
name=runner_gitlab-runner-source
baseurl=https://packages.gitlab.com/runner/gitlab-runner/el/7/SRPMS
repo_gpgcheck=1
gpgcheck=0
enabled=1
gpgkey=https://packages.gitlab.com/runner/gitlab-runner/gpgkey
       https://packages.gitlab.com/runner/gitlab-runner/gpgkey/runner-gitlab-runner-4C80FB51394521E9.pub.gpg
       https://packages.gitlab.com/runner/gitlab-runner/gpgkey/runner-gitlab-runner-49F16C5CC3A0F81F.pub.gpg
sslverify=1
sslcacert=/etc/pki/tls/certs/ca-bundle.crt
metadata_expire=300
```

## yum 安装
`yum install -y gitlab-runner-12.2.0-1`

## gitlab项目页面复制token
`Settings > CI/CD > Runners > Set up a specific Runner manually > 复制token`

## gitlab runner主机注册
`gitlab-runner register  --non-interactive --url "http://10.0.0.88/" --registration-token "xxx" --executor "shell"`


## gitlab项目页面查看是否添加成功
`Settings > CI/CD > Runners > Runners activated for this project`