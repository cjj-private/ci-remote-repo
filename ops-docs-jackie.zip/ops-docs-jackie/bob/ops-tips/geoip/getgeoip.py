import hashlib
import os
import shutil
import tarfile

import oss2
import requests

here = os.path.abspath(os.path.dirname(__file__))
download_url = 'https://download.maxmind.com/geoip/databases/GeoLite2-City/download?suffix=tar.gz'
verify_url = 'https://download.maxmind.com/geoip/databases/GeoLite2-City/download?suffix=tar.gz.sha256'
auth = (os.getenv('AccountID'), os.getenv('LicenseKey'))


def alarm(markdown):
    url = 'https://teams'
    payload = {'text': markdown}

    requests.post(url, json=payload)


def sha256sum(filepath):
    h = hashlib.sha256()
    b = bytearray(128*1024)
    mv = memoryview(b)
    with open(filepath, 'rb', buffering=0) as f:
        for n in iter(lambda : f.readinto(mv), 0):
            h.update(mv[:n])

    return h.hexdigest()


def download(url, filepath):
    try:
        with requests.get(url, auth=auth, stream=True) as r:
            r.raise_for_status()
            with open(filepath, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
    except Exception as ex:
        alarm(f'## geolite2 ip\n### 下载失败: {ex}')


def verify():
    try:
        df = os.path.join(here, 'GeoLite2-City.tar.gz')
        vf = os.path.join(here, 'geo-sha256')
        download(download_url, df)
        download(verify_url, vf)

        with open(vf, 'r') as v:
            sha256 = v.read().split(' ')[0].strip()

        assert sha256 == sha256sum(df)

        return True
    except Exception as ex:
        alarm(f'## geolite2 ip\n### 校验失败: {ex}')


def extract():
    try:
        df = os.path.join(here, 'GeoLite2-City.tar.gz')
        mmdb = ''
        with tarfile.open(df, 'r:gz') as tar:
            for f in tar:
                if f.name.endswith('.mmdb'):
                    mmdb = f.name
                    tar.extract(f, path=here)
                    break

        return mmdb
    except Exception as ex:
        alarm(f'## geolite2 ip\n### 解压失败: {ex}')


def upload():
    if verify() != True:
        print('verify error.')
        return
        
    try:
        auth = oss2.Auth(os.getenv('OSS_KEY'), os.getenv('OSS_SECRET'))
        bucket = oss2.Bucket(auth, 'https://oss-ap-southeast-1.aliyuncs.com', 'hotcoin-snp-static')

        mmdb = extract()
        res = bucket.put_object_from_file('geolite2-ip/GeoLite2-City.mmdb', os.path.join(here, mmdb))
        if res.status == 200:
            print('upload done')
            folder, _ = mmdb.split('/')
            shutil.rmtree(os.path.join(here, folder))
    except Exception as ex:
        alarm(f'## geolite2 ip\n### 上传失败: {ex}')


if __name__ == '__main__':
    upload()
