# 各个环境k8s开发人员kubectl权限
**通过普通用户kubeconfig认证文件，限制开发人员使用kubectl常用命令即可，防止误操作，关键信息泄露，开发人员跳板机被黑客持有后等风险**

## 生成开发人员kubeconfig
- 创建阿里`ram子账号`，先允许`控制台访问`，授权`AliyunCSReadOnlyAccess`
- 创建`cluster-member`角色，如下图中给bob-test ram子账号授权，业务namespace授予`view`角色，`所有命名空间`授予`cluster-member`角色(用于kubectl top nodes)
	![ram privilege](/images/1716258659265.jpg)
- 阿里web ram用户登录，`容器服务kubernetes版` (选择对应集群) > 集群信息 > 连接信息，拷贝认证信息放到开发人员kubectl命令服务器，如/root/.kube下
- 完成，ram用户可关闭`控制台访问`

## 允许的命令
- kubectl get pods
- kubectl logs podid
- kubectl top nodes
- kubectl get nodes
- kubectl top pods | grep xxx
- kubectl get cm
- (等一些常规读操作)

## 不允许的命令
- kubectl exec -it podid -- sh (避免普通用户进入pod，kill掉java业务进程)
- kubectl delete pod podid
- kubectl rollout restart deploy xxx
- kubectl scale deploy xxx --replicas=0
- (等等危险的写操作，临时允许开发人员越权操作，上图中给予`cluster-owner`或`cluster-admin`角色，完成后恢复`view`角色，开发kubeconfig文件无须重新生成)

## 允许访问的namespace
- 开发：default、coin-cluster
- 测试：default、new-cluster
- 生产：default、hotcoin

## 不允许访问的namespace
- kube-system (ingress https证书会以secret对象下挂到该命名空间，开放访问危险)
- nacos (允许普通用户更改十分危险)