import datetime
import os
import time

import oss2
import qrcode
import requests

build_type = os.environ.get('BUILD_TYPE', '')
path = f'/apps/jenkins-test/data/workspace/android/app/build/outputs/apk/Develop/{build_type.lower()}'
img_url= 'https://test-newadminbkt.oss-cn-hongkong.aliyuncs.com/hotcoin/android_apk.jpg'
build_time = time.strftime('%Y-%m-%d-%H-%M-%S', time.localtime(time.time()))

def upload_oss():
    auth = oss2.Auth('xxx', 'xxx')
    bucket = oss2.Bucket(auth, 'http://oss-cn-hongkong-internal.aliyuncs.com', 'test-newadminbkt')

    dirs = os.listdir(path)
    for filename in dirs:
        if ".apk" in filename:
            #print(filename,type(filename))
            #删除旧图片
            #delete_img()
            oss_filename=build_time+"-"+filename
            download_url = 'https://test-newadminbkt.oss-cn-hongkong.aliyuncs.com/hotcoin/'+oss_filename
            result=bucket.put_object_from_file('hotcoin/%s'%(oss_filename), '%s/%s'%(path,filename))
            if result.status == 200:
               #二维码
               img = qrcode.make(data=download_url)
               img.save("/data/scripts/apk.jpg")
               img_filename=build_time+"-"+filename
               bucket.put_object_from_file('hotcoin/%s.jpg'%(img_filename),'/data/scripts/apk.jpg')
 #              with open('/data/scripts/jpg.txt','w') as f1:
 #                   f1.write(filename)

               #with open('/root/.jenkins/workspace/android/changelog','r') as f2:
               #     commit_info=f2.read()

               send_markdown_msg(download_url, img_filename)
            else:
                print("apk上传不成功")


def send_markdown_msg(download_url, img_name):
    branch = os.environ.get('BRANCH', '')
    job_url = os.environ.get('JOB_URL', '')
    build_id = os.environ.get('BUILD_ID', '')
    change_log = os.environ.get('CHANGELOG', '')
    markdown = '## 测试版apk打包成功\n'
    markdown += f'### 分支: {branch}\n'
    markdown += f'### 编号: [#{build_id}]({job_url})\n'
    markdown += f'### 构建类型: {build_type}\n'
    markdown += f'### 安装包: [点击或扫码下载↓]({download_url})\n'
    markdown += f'### 提交记录:\n{change_log}\n'
    markdown += f'![screenshot](https://test-newadminbkt.oss-cn-hongkong.aliyuncs.com/hotcoin/{img_name}.jpg)\n'

    teams_url = 'https://teams'
    payload = {'text': markdown}
    requests.post(teams_url, json=payload)


upload_oss()
