import os

import dateutil
import oss2
import requests
import yaml

dmg_path = os.getenv('DMG_PATH', '')
build_id = os.getenv('BUILD_ID', '')
build_url = os.getenv('BUILD_URL', '')
sha = os.getenv('SHA', '')
commit_info = os.getenv('COMMIT_INFO', '')
title = os.getenv('TITLE', '')
oss_key = os.getenv('OSS_KEY', '')
branch = os.getenv('BRANCH', '')
#print(dmg_path, build_id, build_url, sha, commit_info, title, oss_key, branch)

def get_upload_info(build_path):
    with open(os.path.join(build_path, 'latest-mac.yml')) as f:
        data = yaml.safe_load(f)

    dmg_file = ''
    for dmg in data['files']:
        if dmg['url'].endswith('.dmg'):
            dmg_file = dmg['url']
            break

    return dmg_file, data['releaseDate']


def get_oss_bucket():
    auth = oss2.Auth(oss_key, 'xxx')
    bucket = oss2.Bucket(auth, 'https://oss-cn-hongkong.aliyuncs.com', 'dev-appbkt')

    return bucket


def send_msg(dmg_oss_path, latestfile_oss_path, latestfile_name):
    markdown = f'## {title}web mac端打包成功\n### 分支: {branch}, sha: {sha}\n### 提交信息: {commit_info}\n'
    markdown += f'### latest file：[{latestfile_name}]({latestfile_oss_path})\n### 流水线：[#{build_id}]({build_url})\n'
    markdown += f'### 安装包：[点击下载]({dmg_oss_path})\n'
    payload = {'text': markdown}
    url = 'https://teams'

    requests.post(url, json=payload)


def upload_to_oss():
    dmg_file, datetime_str = get_upload_info(dmg_path)
    if not dmg_file:
        return
    bucket = get_oss_bucket()

    dt = dateutil.parser.isoparse(datetime_str).astimezone(dateutil.tz.gettz('Asia/Shanghai'))
    dt_str = dt.strftime('%Y-%m-%d-%H-%M-%S')

    dmg_oss_path = f'hotcoin/{dt_str}-{dmg_file}'
    latestfile_oss_path = f'hotcoin/latest-mac_{dt_str}.yml'
    bucket.put_object_from_file(dmg_oss_path, f'{os.path.join(dmg_path, dmg_file)}')
    bucket.put_object_from_file(latestfile_oss_path, f'{os.path.join(dmg_path, "latest-mac.yml")}')

    oss_url_prefix = 'https://dev-appbkt.oss-cn-hongkong.aliyuncs.com/'
    send_msg(f'{oss_url_prefix}{dmg_oss_path}', f'{oss_url_prefix}{latestfile_oss_path}', f'latest-mac_{dt_str}.yml')

#print(get_upload_info(dmg_path))
upload_to_oss()
