import json
import uuid

#import pyjson5
import pymysql

db0 = dict(host='127.0.0.1', user='root', password='xxx', database='cisco', charset='utf8')

with open('config_tpl.json') as f:
    # data = pyjson5.load(f)  # pyjson5可读取带注释的json文件
    data = json.load(f)


with pymysql.connect(**db0) as conn:
    with conn.cursor() as cur:
        cur.execute('select username from user where status=1')
        for i in cur.fetchall():
            # uid = uuid.uuid4().hex
            uid = str(uuid.uuid4())  # 需带"-"号的uuid，否则shadowrocket app无法使用
            v2ray = {'id': uid, 'level': 1, 'alterId': 64, 'email': f'{i[0]}@llpp.top'}
            mtproto = {'secret': uid}
            data['inbounds'][0]['settings']['clients'].append(v2ray) 
            # data['inbounds'][1]['settings']['users'].append(mtproto)  # TODO v2ray中tg用的mtproto只支持一个uuid


with open('config.json', 'w') as f:
    json.dump(data, f, indent=2)
