## V2link
- 从cisco vpn中数据库读取用户，产生config.josn文件后复制到当前目录，生成vmess连接、二维码
- 可定期更换连接，防止老的连接被滥用

### dev
- py3.6+, pip install -r requirements.txt
- gencfg.py  # 生成v2ray启动时需要config.json文件、v2ray用户
- app.py  # web
