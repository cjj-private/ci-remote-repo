import base64
import json
from datetime import timedelta

import pymysql
from flask import Flask, url_for, request, redirect, render_template, g, flash, session
from pyotp import TOTP
from werkzeug.local import LocalProxy

app = Flask(__name__)
app.secret_key = 'asda..23'
db0 = dict(host='127.0.0.1', user='root', password='xxx', database='cisco', charset='utf8')

def get_v2ray_data():
    with open('config.json') as f:
        data = json.load(f)
    return data

@app.before_request
def exp():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(minutes=15)

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = pymysql.connect(**db0)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

db = LocalProxy(get_db)
v2rdata = LocalProxy(get_v2ray_data)  # 修改json文件后无需重启


@app.route('/my-v2link')
def link():
    if 'username' in session:
        username = session['username']
        for i in v2rdata['inbounds'][0]['settings']['clients']:
            if f'{username}@' in i['email'] and i['email'].endswith('llpp22.top'):
                v2j = {'add': 'i2f.jmk666.top', 'aid': '64', 'alpn': '', 'fp': '', 'host': '', 'id': i['id'], 'net': 'ws', 'path': '/v2rayacd069d6eedf', 'port': '46256', 'ps': 'cross0613', 'scy': 'auto', 'sni': '', 'tls': 'tls', 'type': '', 'v': '2'}
                vmess = f'vmess://{base64.b64encode(json.dumps(v2j).encode()).decode()}'
                mtproto = f'https://t.me/proxy?server=i2f.jmk666.top&port=6666&secret={i["id"]}'
                break
        return render_template('link.html', title='v2link-我的代理', username=username, vmess=vmess, mtproto=mtproto)

    return redirect(url_for('index'))


@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('link'))

    return render_template('index.html', title='v2link-首页')
    

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username', ' ', str)
    code = request.form.get('password', ' ', str)
    try:
        with db.cursor() as cur:
            cur.execute(f'select username,otp_secret from user where username="{username}" and status=1')
            name, otp_sec = cur.fetchone()
        
        if TOTP(otp_sec).verify(code):
            session['username'] = name
            return redirect(url_for('link'))
        else:
            flash('用户名或密码错误')
            return redirect(url_for('index'))
    except Exception:
        flash('用户名或密码错误')
        return redirect(url_for('index'))


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))


@app.route('/about')
def about():
    if 'username' in session:
        return render_template('about.html', title='v2link-关于')

    return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)

