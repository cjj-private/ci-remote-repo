# CICD相关实践(jenkins)

## jenkins文档
- [官方文档](https://www.jenkins.io/doc/book/)
- [视频教程](https://www.youtube.com/@CloudBeesTV/videos)
## 实践
### 开发环境
- 声明式pipeline为主
### 测试环境
- git仓库管理声明式pipeline，helm模版渲染
- 目录管理
### 生产环境
- 脚本式+声明式pipeline
## 任务类型
### 自由风格
- 简单的、调用jenkins本机上的命令组合、shell脚本
### Pipeline流水线
#### 1 脚本式
- 多个stage完成任务
#### 2 声明式
- 多个stage完成任务
- 官方提供高效功能
