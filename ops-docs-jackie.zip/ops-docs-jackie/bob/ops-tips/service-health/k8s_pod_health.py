import json
import logging
from datetime import datetime

import requests
from apscheduler.schedulers.blocking import BlockingScheduler
from kubernetes import client, config

logging.basicConfig(level=logging.INFO)
sched = BlockingScheduler()
k8s = {
    '现货测试环境': {'config': '/root/.kube/spot', 'namespaces': ['default', 'new-cluster']},
    '合约测试环境': {'config': '/root/.kube/contract', 'namespaces': ['default']},
}


def alarm(markdown):
    url = 'https://teams'
    payload = {'text': markdown}

    requests.post(url, json=payload)


@sched.scheduled_job('interval', seconds=20)
def tick():
    hour = datetime.now().strftime('%Y%m%d%H')
    with open('alarm.json') as fi:
        data = json.load(fi)

    for i in list(data):
        if i < hour:
            data.pop(i)

    for env, value in k8s.items():
        config.load_kube_config(value['config'])
        v1 = client.CoreV1Api()

        for namespace in value['namespaces']:
            for i in v1.list_namespaced_event(namespace).items:
                if i.reason in ['Unhealthy', 'BackOff'] and any(e in i.message for e in ['Readiness probe failed', 'Liveness probe failed', 'Back-off']):
                    pod_id = i.involved_object.name
                    if not data.get(hour) or pod_id not in data.get(hour):
                        data.setdefault(hour, []).append(pod_id)
                        alarm(f'## {env}k8s pod不健康\n### namespace: {namespace}\n### pod: {pod_id}\n ### 原因: {i.message}')

    with open('alarm.json', 'w') as fi:
        json.dump(data, fi)


#tick()
sched.start()
