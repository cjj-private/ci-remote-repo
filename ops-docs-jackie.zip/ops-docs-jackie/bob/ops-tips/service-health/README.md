## 服务健康检查

## pod健康
- k8s_pod_health.py  # 20秒检查一次，k8s event保存1小时，alarm.json不健康的pod告警过不在告警

## 中间件健康
