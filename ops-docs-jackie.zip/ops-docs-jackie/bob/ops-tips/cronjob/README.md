# 定时任务

## 测试环境
-  test_mysql_truncate.py # mysql大表清理