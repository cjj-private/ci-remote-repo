from types import SimpleNamespace

import pymysql
import requests

perpetual = SimpleNamespace(
    tables=['mark_price', 'follow_trigger_order'],
    db=dict(host='mysql', user='xxx', password='xxx', database='perpetual', charset='utf8'),
)

market = SimpleNamespace(
    tables=['pair_code_market_index', ],
    db=dict(host='mysql', user='xxx', password='xxx', database='market', charset='utf8'),
)

deliver = SimpleNamespace(
    tables=['mark_price'],
    db=dict(host='mysql', user='xxx', password='xxx', database='deliver', charset='utf8'),
)

instances = [perpetual, market, deliver]


def alarm(markdown):
    url = 'https://teams'
    payload = {'text': markdown}
    
    requests.post(url, json=payload)


def truncate():
    for inst in instances:
        try:
            with pymysql.connect(**inst.db) as conn:
                with conn.cursor() as cur:
                    for table in inst.tables:
                        try: cur.execute(f'truncate table {table}')
                        except Exception as ex: print(ex)
        except Exception as ex:
            alarm(f'## 测试环境mysql清理\n### 异常: {ex}')


if __name__ == '__main__':
    truncate()