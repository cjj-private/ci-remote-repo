import re
import logging
from datetime import datetime, timedelta

from apscheduler.schedulers.tornado import TornadoScheduler
from motor.motor_tornado import MotorClient
from pymongo import UpdateOne
from tornado.ioloop import IOLoop
import aiohttp

scheduler = TornadoScheduler()
logging.basicConfig(level=logging.INFO)

def get_mongo_conn():
    uri = 'mongodb://user:bar@mongo:27017/db'
    conn = MotorClient(uri)
    return conn


async def alarm(markdown):
    url = 'https://teams'
    payload = {'text': markdown}
    logging.info(payload)

    async with aiohttp.ClientSession() as session:
        await session.post(url, json=payload)


@scheduler.scheduled_job('interval', seconds=300)
async def delete_no_pod():
    conn = get_mongo_conn()
    db = conn.fluentd

    await db.log.delete_many({'pod': {'$exists': False}})  


@scheduler.scheduled_job('interval', seconds=60)
async def delete_doc():
    conn = get_mongo_conn()
    db = conn.fluentd
    count = await db.log.count_documents({})
    now = datetime.utcnow()

    if count < 200000:
        delta = now - timedelta(hours=12)
    elif count in range(200000, 400000):
        delta = now - timedelta(hours=8)
    elif count in range(400000, 600000):
        delta = now - timedelta(hours=6)
    elif count in range(600000, 1000000):
        delta = now - timedelta(hours=2)
    else:
        delta = now - timedelta(minutes=30)

    rs = await db.log.delete_many({'checked': {'$exists': True}, 'timestamp': {'$lt': delta}})  
    logging.info(f'删除已分析数据: 现存 {count} 删除 {rs.deleted_count}')


async def parser(srv_name, ids):
    conn = get_mongo_conn()
    db = conn.fluentd
    now = datetime.utcnow()
    date = datetime.strptime(now.strftime('%Y%m%d'), '%Y%m%d')
    logging.info(f'task {srv_name}: {len(ids)}')

    lst = []
    pattern = re.compile(r'\w+Exception')
    async for i in db.log.find({'_id': {'$in': ids}}, {'log': 1}):
        lst.extend(pattern.findall(i['log']))
    exception0 = {i: lst.count(i) for i in lst}
    query = {'date': date, 'srv_name': srv_name}
    one = await db.stats.find_one(query) or {}
    exception1 = one.get('exceptions', {})  # 为空告警

    diff = exception0.keys() - exception1.keys()  # 有差集告警
    flag = True if diff else False
    inc = {f'exceptions.{k}': v for k, v in exception0.items()}
    await db.stats.update_one(query, {'$inc': inc, '$set': {'updateTime': datetime.utcnow()}},
                              upsert=flag)  # True 8点生成每日数据(utc)
    logging.info(f'{srv_name} {exception0}')
    if flag:
        result = await db.stats.find_one(query)
        inc_text = ''.join(f' - {k}: {v}\n' for k, v in result['exceptions'].items())
        webpage = f'### 服务: {srv_name} [查看日志](http://172.18.44.2:30817/app/{srv_name})'
        markdown = f'## 生产环境异常日志\n{webpage}\n### 新增: {", ".join(diff)}\n### 累计:\n{inc_text}'
        await alarm(markdown)

    updates = [UpdateOne({'_id': i}, {'$set': {'checked': True}}) for i in ids]
    await db.log.bulk_write(updates, ordered=False)


@scheduler.scheduled_job('interval', seconds=30)
async def tick():
    logging.info(f'tick start at {datetime.now()}')
    conn = get_mongo_conn()
    db = conn.fluentd

    # 不用aggregate，数据量大时，定时任务会卡死
    # pipeline = [{'$match': {'checked': {'$exists': False}, 'pod': {'$exists': True}}},
    #             {'$group': {'_id': '$pod', 'ids': {'$push': '$_id'}, }},]
    dct = {}
    query = {'checked': {'$exists': False}, 'pod': {'$exists': True}}
    async for i in db.log.find(query, {'pod': 1}).sort('_id', -1).limit(10000):
        *_, srv_name = i['pod'].split('_default_')
        if 'service-match' in srv_name:
            srv_name = re.sub(r'-\d+', '', srv_name)
        dct.setdefault(srv_name, []).append(i['_id'])  # 以服务名做一次聚合

    # 任务均分
    lst, step = [], 800
    for srv_name, ids in dct.items():
        if len(ids) > 1500:
            for _ids in (ids[x: x+step] for x in range(0, len(ids), step)):
                lst.append((srv_name, _ids))
        else:
            lst.append((srv_name, ids))
    tasks = [asyncio.create_task(parser(i[0], i[1])) for i in lst]
    await asyncio.wait(tasks)
    logging.info(f'tick finish at {datetime.now()}')


scheduler.start()
IOLoop.current().start()
