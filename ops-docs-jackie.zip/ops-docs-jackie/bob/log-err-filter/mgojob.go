package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"os"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/go-co-op/gocron"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

var deployEnv = getEnv("DeployEnv", "test")
var webLogUrl = getEnv("WebLogUrl", "")
var keepHours = getEnv("KeepHours", "24")
var limitDocs = getEnv("LimitDocs", "20000")
var mongoHost = getEnv("MongoHost", "mongo:27017")
var mongoAuth = getEnv("MongoAuth", "usr:pwd")
var dbName = getEnv("DBName", "fluentd")
var msgUrl = getEnv("MsgUrl", "http://xxx")
var exPatterns = getEnv("ExPatterns", `\w*Exception`)
var pattern1 = regexp.MustCompile(exPatterns)
var startDate = "2006-01-02"
var wg sync.WaitGroup

// 异常日志表
type Plog struct {
	Id      primitive.ObjectID `bson:"_id"`
	SrvName string             `bson:"srv_name"`
	Log     string             `bson:"log"`
}

// 异常统计表
type Stats struct {
	SrvName    string             `bson:"srv_name"`
	Date       primitive.DateTime `bson:"date"`
	Exceptions map[string]int64   `bson:"exceptions"`
}

func getEnv(key, defaultValue string) string {
	value := os.Getenv(key)
	if len(value) == 0 {
		return defaultValue
	}
	return value
}

func getMongoConn() *mongo.Database {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(10*time.Second))
	defer cancel()
	uri := fmt.Sprintf("mongodb://%s@%s/%s", mongoAuth, mongoHost, dbName)
	client, _ := mongo.Connect(ctx, options.Client().ApplyURI(uri))

	return client.Database(dbName)
}

func sendMsg(markdown string) {
	payload := map[string]string{"text": markdown}
	buf, _ := json.Marshal(payload)

	if res, err := http.Post(msgUrl, "application/json", bytes.NewBuffer(buf)); err == nil {
		defer res.Body.Close()
	}
}

// 删除没有srv_name字段的数据，fluentd mongo可能会产生脏数据
func delNoPod() {
	db := getMongoConn()
	coll := db.Collection("log")
	query := bson.M{"srv_name": bson.M{"$exists": false}}
	if res, err := coll.DeleteMany(context.TODO(), query); err == nil {
		log.Println("<delete no srv_name> delete:", res.DeletedCount)
	}
	db.Client().Disconnect(context.TODO())
}

// 删除已检查过的异常数据, 根据数据量删除
func delCheckedDoc() {
	db := getMongoConn()
	coll := db.Collection("log")
	count, _ := coll.CountDocuments(context.TODO(), bson.M{})
	now := time.Now().UTC()
	hours, _ := strconv.Atoi(keepHours)
	diff := now.Add(time.Hour * -time.Duration(hours))

	query := bson.M{"time": bson.M{"$lt": diff}}
	if res, err := coll.DeleteMany(context.TODO(), query); err == nil {
		log.Println("<delete checked docs> current docs:", count, "delete:", res.DeletedCount)
	}
	db.Client().Disconnect(context.TODO())
}

func alarm(diffs string, one Stats) {
	var inc_text, env string
	for k, v := range one.Exceptions {
		inc_text += fmt.Sprintf(" - %s: %d\n", k, v)
	}
	if deployEnv == "test" {
		env = "测试环境异常日志"
	} else {
		env = "生产环境异常日志"
	}
	wp := "### 服务: %s [查看日志](%s/%s)"
	md := "## %s\n%s\n### 新增: %s\n### 累计:\n%s"
	webpage := fmt.Sprintf(wp, one.SrvName, webLogUrl, one.SrvName)
	markdown := fmt.Sprintf(md, env, webpage, diffs, inc_text)
	log.Println(markdown)

	sendMsg(markdown)
}

func getDiff(ex map[string]int64, one Stats) []string {
	diff := make([]string, 0) //差集
	for k := range ex {
		if _, ok := one.Exceptions[k]; !ok {
			diff = append(diff, k)
		}
	}

	return diff
}

func getExInc(ids []primitive.ObjectID, collLog *mongo.Collection) (map[string]int64, bson.M) {
	batch := []Plog{}
	var logs string
	exception := make(map[string]int64)
	inc := bson.M{} //增量内嵌文档
	cursor, _ := collLog.Find(context.TODO(), bson.M{"_id": bson.M{"$in": ids}})
	_ = cursor.All(context.TODO(), &batch)
	for _, i := range batch {
		logs += i.Log
	}
	for _, ex := range pattern1.FindAllString(logs, -1) {
		exception[ex]++
	}
	for k, v := range exception {
		inc["exceptions."+k] = v
	}

	return exception, inc
}

// 解析异常日志，有新增告警
func checkException(srvName string, ids []primitive.ObjectID) {
	log.Printf("<task> %s: %d \n", srvName, len(ids))
	defer wg.Done()
	db := getMongoConn()
	collLog := db.Collection("log")
	collStats := db.Collection("stats")

	exception, inc := getExInc(ids, collLog) // 获取解析数据
	now := time.Now().UTC()
	dt, _ := time.Parse(startDate, now.Format(startDate))
	ut := bson.M{"updateTime": now}
	query := bson.M{"date": dt, "srv_name": srvName}
	log.Println(srvName, exception)

	var one Stats
	_ = collStats.FindOne(context.TODO(), query).Decode(&one)
	diff := getDiff(exception, one) //有差集告警
	opts := options.Update().SetUpsert(true)
	collStats.UpdateOne(context.TODO(), query, bson.M{"$inc": inc, "$set": ut}, opts)
	if len(diff) > 0 {
		_ = collStats.FindOne(context.TODO(), query).Decode(&one)
		alarm(strings.Join(diff, ", "), one)
	}

	// 本次定时任务的数据设为已检查
	query, update := bson.M{"_id": bson.M{"$in": ids}}, bson.M{"$set": bson.M{"checked": true}}
	if res, err := collLog.UpdateMany(context.TODO(), query, update); err == nil {
		log.Printf("<task> %s finish, modified: %d\n", srvName, res.ModifiedCount)
	}

	db.Client().Disconnect(context.TODO()) //必须关闭
}

// go1.18+ 范型
func chunkBy[T any](items []T, chunkSize int) (chunks [][]T) {
	for chunkSize < len(items) {
		items, chunks = items[chunkSize:], append(chunks, items[0:chunkSize:chunkSize])
	}
	return append(chunks, items)
}

func dispatcher() {
	db := getMongoConn()
	coll := db.Collection("log")
	batch := []Plog{}

	// mongod缓存限制3GB，不用aggregate数据量大时定时任务卡死
	limit, _ := strconv.ParseInt(limitDocs, 10, 64)
	project, sort := bson.M{"srv_name": 1}, bson.M{"_id": -1}
	opts := options.Find().SetProjection(project).SetSort(sort).SetLimit(limit)
	query := bson.M{"checked": bson.M{"$exists": false}}
	cursor, _ := coll.Find(context.TODO(), query, opts)
	if err := cursor.All(context.TODO(), &batch); err != nil {
		log.Println(err)
	}
	res := make(map[string][]primitive.ObjectID)
	for _, i := range batch {
		srvName := i.SrvName
		if strings.HasPrefix(srvName, "service-match") {
			t := strings.SplitN(srvName, "-", 3)
			srvName = t[0] + "-" + t[1]
		}
		res[srvName] = append(res[srvName], i.Id) //以服务名做聚合
	}
	// 任务均分并发
	for srvName, ids := range res {
		if len(ids) > 1500 {
			for _, i := range chunkBy(ids, 800) {
				wg.Add(1)
				go checkException(srvName, i)
			}
		} else {
			wg.Add(1)
			go checkException(srvName, ids)
		}
	}

	wg.Wait()
	db.Client().Disconnect(context.TODO()) //必须关闭
	log.Println("wg done.")
}

func main() {
	s := gocron.NewScheduler(time.Local)
	s.Every(20).Seconds().Do(dispatcher)
	s.Every(120).Seconds().Do(delCheckedDoc)
	s.Every(120).Seconds().Do(delNoPod)
	s.StartBlocking()
}
