# weblog
quart + bootstrap web展示服务异常日志

## dev
```
# python 3.7+
pip3 install -r requirements.txt -i https://pypi.douban.com/simple

python app.py
```

