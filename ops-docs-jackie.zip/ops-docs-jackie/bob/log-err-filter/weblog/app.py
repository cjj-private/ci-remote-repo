import os
import re
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace

# 如需要引用flask插件, 参考: https://pgjones.gitlab.io/quart/how_to_guides/flask_extensions.html
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorClient
from quart import Quart, g, request, render_template, flash, redirect, url_for
from werkzeug.local import LocalProxy


app = Quart(__name__)
env = os.getenv('DEPLOY_ENV', 'test')
cfg = SimpleNamespace(
    env=env,
    title='测试环境异常日志' if env == 'test' else '生产环境异常日志',
    max_page=int(os.getenv('MAX_PAGE', '100')),
    re_pattern=os.getenv('RE_PATTERN', r'\w+Exception|has already been matched or canceled'),
    mongo_uri=os.getenv('MONGO_URI', 'mongodb://fluent:ffff1122@172.18.44.2:31327'),
    db=os.getenv('DB_NAME', 'fluentd'),
)
pattern = re.compile(r'{}'.format(cfg.re_pattern))
app.config['SECRET_KEY'] = 'xasdadsad;'

def get_db():
    if 'db' not in g:
        client = AsyncIOMotorClient(f'{cfg.mongo_uri}/{cfg.db}')
        g.db = client[cfg.db]
    
    return g.db

def find_all_ex(s):
    return ', '.join(set(pattern.findall(s)))

def utc_to_local(utc_dt, fmt='%Y/%m/%d %H:%M:%S'):
    return utc_dt.replace(tzinfo=timezone.utc).astimezone(tz=None).strftime(fmt)

def branded_title(s):
    return s or cfg.title

app.jinja_env.filters['find_all_ex'] = find_all_ex
app.jinja_env.filters['utc_to_local'] = utc_to_local
app.jinja_env.filters['branded_title'] = branded_title
db = LocalProxy(get_db)

@app.route('/')
async def index():
    td = datetime.utcnow() - timedelta(days=14)
    pt = datetime.strptime(td.strftime('%Y%m%d'), '%Y%m%d')
    data = {}
    async for i in db.stats.find({'date': {'$gte': pt}}).sort('date', -1):
        data.setdefault(i['date'], {}).update({i['srv_name']: i['exceptions']})

    return await render_template('index.html', data=data, title=f'{cfg.title}-首页')


@app.route('/about')
async def about():
    return await render_template('about.html', title=f'{cfg.title}-关于')


@app.route('/app/<srv_name>')
async def app_page(srv_name):
    page_index = request.args.get('page-index', 1, type=int)
    page_size = request.args.get('page-size', cfg.max_page, type=int)

    if srv_name.startswith('service-match'):
        query = {'srv_name': {'$regex': f'{srv_name}-'}}
    else:
        query = {'srv_name': srv_name}
    total = await db.log.count_documents(query)
    if total == 0:
        await flash(f'{srv_name} 12个小时内无异常数据')
        return redirect(url_for('index'))
    page_count = int((total + page_size -1) / page_size)
    skip = (page_index - 1) * page_size
    docs = await db.log.find(query).sort('_id', -1).skip(skip).limit(page_size).to_list(None)

    return await render_template('app.html', data=docs, srv_name=srv_name, title=f'{cfg.title}-{srv_name}',
                                 page_count=page_count, total=total, current_page=page_index, page_size=page_size)


@app.route('/app/<srv_name>/log/<log_id>')
async def log_page(srv_name, log_id):
    one = await db.log.find_one({'_id': ObjectId(log_id)})
    log = one['log']
    ex = find_all_ex(log)
    for i in set(pattern.findall(log)):
        log = log.replace(i, f'<b>{i}</b>')  # 高亮异常
    one['log'] = log
    return await render_template('log.html', data=one, ex=ex, srv_name=srv_name, title=f'{cfg.title}-{srv_name}')


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
