# log-err-filter

## 主要文件说明
- filter-err-log.yaml helm安装fluentd的资源文件，内含fluentd配置
- mongo.yaml k8s上安装mongo
- mgojob.py 定时任务去处理存入mongo的服务异常日志
- mgojob.go 功能同mgojob.py
- weblog web展示服务异常日志

### filter-err-log.yaml
```
把bitnami/fluentd fetch下来
构建镜像Dockerfile.fluentd
helm -n logging upgrade --install fluentd-err-filter -f filter-err-log.yaml .
```

### mgojob.go
```
几个定时任务说明
delNoPod()  # 删除没有pod字段文档，可能fluentd mongo会产生脏数据
delCheckedDoc()  # 删除已分析过异常的数据，根据当前数据量的去删除
dispatcher()  # 匹配异常、增量告警
```

### mongo.yaml
configmap
```
mongod.conf: |
  security:
    # 第一次apply时`disabled`，running后进入pod，创建后管理员账号
    # 再enabled，apply重启pod，否则pod被重启后丢失已有授权账户
    authorization: enabled
```
创建管理员账户
```
mongosh
use admin
db.createUser({user: 'admin', pwd: 'xxx', roles: [{role: 'userAdmin', db: 'admin'}]})
```
创建普通账户
```
mongosh
use admin
db.auth('admin', 'xxx')
use fluentd
db.createUser({user: 'foo', pwd: 'bar', roles: [{role: 'readWrite', db: 'fluentd'}]})
```
