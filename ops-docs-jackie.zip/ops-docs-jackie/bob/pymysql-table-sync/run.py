import re
from datetime import datetime, timedelta

import MySQLdb
import requests
from dateutil.relativedelta import relativedelta

from config import instances, history_db

day = datetime.now().strftime('%Y%m%d')
#day = '20231007'
sub_pattern1 = re.compile(r'BY\s+GROUP|dbpartition\s+by.*\)', re.IGNORECASE)
sub_pattern2 = re.compile(r'CHARACTER\s+SET\s+\w+\s+COLLATE\s+\w+', re.IGNORECASE)


def alarm(markdown):
    url = 'https://teams'
    payload = {'text': markdown,}

    requests.post(url, json=payload)


def create_table(table_name, ddl):
    ddl = sub_pattern1.sub('', ddl)
    ddl = sub_pattern2.sub('CHARACTER SET utf8mb4', ddl)
    ddl = ddl.replace('utf8mb3', 'utf8mb4')
    try:
        with MySQLdb.connect(**history_db) as conn:
            with conn.cursor() as cursor:
                cursor.execute(ddl)
                conn.commit()
    except Exception as ex:
        alarm(f'## 数据同步\n### 创表失败: {table_name}\n### {ex}')


def sync():
    for inst in instances:
        new_table_name = f'{inst.table_name}_pnlrpt_{day}'
        if inst.db['database'] == 'deliver':
            new_table_name = f'deliver_{new_table_name}'
        try:
            conn_his = MySQLdb.connect(**history_db)
            conn_inst = MySQLdb.connect(**inst.db)
            with conn_inst.cursor() as cursor_inst:
                # 生成create、insert语句
                cursor_inst.execute(f'show create table {inst.table_name}')
                one = cursor_inst.fetchone()[1]
                ddl = one.replace(inst.table_name, new_table_name, 1)
                create_table(new_table_name, ddl)
                cursor_inst.execute(f'select * from {inst.table_name} limit 1')
                values = cursor_inst.fetchone()
                insert = f'insert into {new_table_name} values ({", ".join(["%s"] * len(values))})'

                # 分批查询插入，分库的需order by
                cursor_inst.execute(f'select count(*) from {inst.table_name}')
                count = cursor_inst.fetchone()[0]
                limit, n = 30000, 0
                for offset in range(0, count, limit):
                    sql = f'select * from {inst.table_name} order by id asc limit {offset}, {limit}'
                    cursor_inst.execute(sql)
                    rows = cursor_inst.fetchall()
                    with conn_his.cursor() as cursor_his:
                        cursor_his.executemany(insert, rows)
                        conn_his.commit()
                        n += len(rows)
                if n < count:
                    alarm(f'## 数据同步\n### 同步失败: {new_table_name} {n} < {count}')

            conn_inst.close()
            conn_his.close()
        except Exception as ex:
            alarm(f'## 数据同步\n### 同步失败: {new_table_name}\n### {ex}')


def drop_history():
    today = datetime.now()
    for inst in instances:
        table_name = f'deliver_{inst.table_name}' if inst.db['database'] == 'deliver' else inst.table_name
        prev = today - relativedelta(days=8)  # dev、test
        #prev = today - relativedelta(months=inst.keep_months)  # prod

        # 尝试删除表
        try:
            with MySQLdb.connect(**history_db) as conn:
                with conn.cursor() as cursor:
                    for i in range(3):
                        day = prev - timedelta(days=i)
                        sql = f'drop table {table_name}_pnlrpt_{day.strftime("%Y%m%d")}'
                        try:
                            cursor.execute(sql)
                            conn.commit()
                        except:
                            pass
        except:
            pass


if __name__ == '__main__':
    sync()
    drop_history()
