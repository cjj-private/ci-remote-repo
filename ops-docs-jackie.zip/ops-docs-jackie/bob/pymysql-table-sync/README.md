# pymysql-table-sync

## dev
 - python3.6+
 - pip3 install mysqlclient pymysql requests python-dateutil
 - `mysqlclient`有c依赖性能较好，如无法安装用`pymysql`

