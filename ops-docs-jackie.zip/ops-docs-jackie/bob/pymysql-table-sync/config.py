from types import SimpleNamespace

history_db = dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8')

user_coin_wallet = SimpleNamespace(
    table_name='user_coin_wallet',
    keep_months=6,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

mag_user_cross_wallet = SimpleNamespace(
    table_name='mag_user_cross_wallet',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

mag_user_isolated_wallet = SimpleNamespace(
    table_name='mag_user_isolated_wallet',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

user_otc_coin_wallet = SimpleNamespace(
    table_name='user_otc_coin_wallet',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

finance_user_asset = SimpleNamespace(
    table_name='finance_user_asset',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

dual_invest_order = SimpleNamespace(
    table_name='dual_invest_order',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

user_balance = SimpleNamespace(
    table_name='user_balance',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

user_position = SimpleNamespace(
    table_name='user_position',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

contract = SimpleNamespace(
    table_name='contract',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

deliver_user_balance = SimpleNamespace(
    table_name='user_balance',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

deliver_user_position = SimpleNamespace(
    table_name='user_position',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

deliver_contract = SimpleNamespace(
    table_name='contract',
    keep_months=1,
    db=dict(host='xxx', user='xxx', password='xxx', database='xxx', charset='utf8'),
)

instances = [user_coin_wallet, mag_user_cross_wallet, mag_user_isolated_wallet, user_otc_coin_wallet, finance_user_asset, dual_invest_order, user_balance, user_position, contract, deliver_user_balance, deliver_user_position, deliver_contract]
#instances = [user_coin_wallet, ]
